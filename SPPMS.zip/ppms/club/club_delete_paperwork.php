<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['clubID'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
    exit();
}

// Check if ID was provided
if (!isset($_POST['id'])) {
    echo json_encode(['status' => 'error', 'message' => 'No paperwork ID provided']);
    exit();
}

// Database connection
include('../connection.php');

if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit();
}

// Get the clubID from session and paperwork ID from POST
$clubID = $_SESSION['clubID'];
$paperworkID = $_POST['id'];

// First, verify that this paperwork belongs to the club and is not approved
$checkSql = "SELECT status FROM paperwork WHERE id = ? AND clubID = ?";
$checkStmt = $conn->prepare($checkSql);
$checkStmt->bind_param("ii", $paperworkID, $clubID);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Paperwork not found']);
    $checkStmt->close();
    $conn->close();
    exit();
}

$row = $checkResult->fetch_assoc();
if (strtolower($row['status']) === 'diluluskan') {
    echo json_encode(['status' => 'error', 'message' => 'Cannot delete approved paperwork']);
    $checkStmt->close();
    $conn->close();
    exit();
}

// Delete the paperwork
$deleteSql = "DELETE FROM paperwork WHERE id = ? AND clubID = ?";
$deleteStmt = $conn->prepare($deleteSql);
$deleteStmt->bind_param("ii", $paperworkID, $clubID);

if ($deleteStmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Paperwork deleted successfully']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to delete paperwork']);
}

$deleteStmt->close();
$conn->close();
?>