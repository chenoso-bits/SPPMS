<?php
session_start(); // Start session

include('../connection.php'); // Include database connection

// Check if the form was submitted (only handle login logic for POST requests)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['clubUsername']) && isset($_POST['clubPassword'])) {
        // Retrieve submitted data
        $clubUsername = $_POST['clubUsername'];
        $clubPassword = $_POST['clubPassword'];

        // Prepare and execute the SQL query
        $sql = "SELECT * FROM club WHERE clubUsername=? AND clubPassword=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $clubUsername, $clubPassword);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row) {
            // Store user data in session
            $_SESSION['clubUsername'] = $row['clubUsername'];
            $_SESSION['clubName'] = $row['clubName'];
            $_SESSION['clubDimension'] = $row['clubDimension'];
            $_SESSION['clubDescription'] = $row['clubDescription'];
            $_SESSION['clubType'] = $row['clubType'];
            $_SESSION['clubID'] = $row['clubID'];

            // Redirect based on user type
            if ($row['clubType'] == "mpp") {
                header("Location: mpp/mpp_homepage.php");
                exit();
            } elseif ($row['clubType'] != "mpp") {
                header("Location: club_homepage.php");
                exit();
            }
        } else {
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Login Failed',
                            text: 'Invalid login credentials.',
                            confirmButtonColor: '#3085d6'
                        });
                    });
                  </script>";
        }

        $stmt->close();
    } else {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Missing Information',
                        text: 'Club Username and Password are required.',
                        confirmButtonColor: '#3085d6'
                    });
                });
              </script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="club_login.php">
    <title>Club Login</title>
    <!-- Add SweetAlert2 CSS and JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* General styles */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            color: #333;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden; /* Prevent scrolling */
            background: linear-gradient(315deg, #02f7db 3%, #2BC6ED 38%, #2B89ED 68%, #2B4BED 98%);
            animation: gradient 15s ease infinite;
            background-size: 400% 400%;
            background-attachment: fixed;
        }

        @keyframes gradient {
            0% {
                background-position: 0% 0%;
            }
            50% {
                background-position: 100% 100%;
            }
            100% {
                background-position: 0% 0%;
            }
        }

        .wave {
            background: rgb(255 255 255 / 25%);
            border-radius: 1000% 1000% 0 0;
            position: fixed;
            width: 200%;
            height: 12em;
            animation: wave 10s -3s linear infinite;
            transform: translate3d(0, 0, 0);
            opacity: 0.8;
            bottom: 0;
            left: 0;
            z-index: -1;
        }

        .wave:nth-of-type(2) {
            bottom: -1.25em;
            animation: wave 18s linear reverse infinite;
            opacity: 0.8;
        }

        .wave:nth-of-type(3) {
            bottom: -2.5em;
            animation: wave 20s -1s reverse infinite;
            opacity: 0.9;
        }

        @keyframes wave {
            2% {
                transform: translateX(1);
            }

            25% {
                transform: translateX(-25%);
            }

            50% {
                transform: translateX(-50%);
            }

            75% {
                transform: translateX(-25%);
            }

            100% {
                transform: translateX(1);
            }
        }

        /* Center container */
        .center {
            width: 300px;
            background: #ffffff; /* White background */
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */
            border-radius: 8px; /* Rounded corners */
            text-align: center;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            opacity: 0; /* Start hidden */
            animation: fadeIn 1s forwards; /* Apply fade-in animation */
            animation-delay: 0.5s; /* Delay for the form */
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translate(-50%, -40%); /* Start slightly above */
            }
            to {
                opacity: 1;
                transform: translate(-50%, -50%); /* End at original position */
            }
        }

        /* Title */
        .center h1 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333; /* Dark text */
        }

        /* Input fields */
        .txt_field {
            margin-bottom: 15px;
            text-align: left;
        }

        .txt_field input {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ccc; /* Light gray border */
            border-radius: 5px; /* Rounded corners */
            font-size: 14px;
            outline: none;
            box-sizing: border-box;
            transition: border-color 0.3s, transform 0.3s; /* Add transition for focus effect */
        }

        .txt_field input:focus {
            border-color: #007bff;
            transform: scale(1.02); /* Slightly scale up on focus */
        }

        .txt_field label {
            font-size: 14px;
            margin-bottom: 5px;
            display: block;
            color: #555; /* Medium gray text */
        }

        /* Submit and Reset buttons */
        input[type="submit"] {
            width: 100%;
            background: #007bff; /* Blue background */
            border: none;
            padding: 10px;
            color: white; /* White text */
            font-size: 16px;
            font-weight: bold;
        border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-bottom: 10px; /* Add spacing between buttons */
        }

        input[type="reset"] {
            width: 100%;
            background: none; /* Blue background */
            border: solid 2px #007bff;
            padding: 10px;
            color: #007bff; /* Blue text */
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-bottom: 10px; /* Add spacing between buttons */
        }

        /* Hover effect for both buttons */
        input[type="submit"]:hover {
            background: #0056b3; /* Darker blue on hover */
        }

        input[type="reset"]:hover {
            width: 100%;
            background: #0056b3;
            border: 2px solid #0056b3;
            color: white;
        }

        /* Signup link */
        .signup_link {
            margin-top: 15px;
            font-size: 14px;
            color: #333; /* Dark text */
        }

        .signup_link a {
            color: #007bff; /* Blue link */
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .signup_link a:hover {
            color: #0056b3; /* Darker blue on hover */
        }

        .radio-toolbar {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div>
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
    </div>
    <div class="center">
        <h1>Club Login</h1>
        <form method="post" action="">
            <div class="txt_field">
                <label>Club Username</label>
                <input type="text" required name="clubUsername">
            </div>
            <div class="txt_field">
                <label>Password</label>
                <input type="password" required name="clubPassword">
            </div>
            <input type="submit" name="submit" value="Login">
        </form>
    </div>
</body>
</html>