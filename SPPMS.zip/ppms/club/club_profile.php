<?php
session_start();

// Add this near the top after session_start()
if (!isset($_SESSION['clubID'])) {
    $_SESSION['message'] = 'Session expired. Please login again.';
    $_SESSION['messageType'] = 'error';
    header('Location: club_login.php'); // Adjust the login page URL as needed
    exit();
}

include('..\connection.php');

$clubID = $_SESSION['clubID'];
$message = '';
$messageType = '';

// Check if there's a message in the session
if (isset($_SESSION['message']) && isset($_SESSION['messageType'])) {
    $message = $_SESSION['message'];
    $messageType = $_SESSION['messageType'];
    // Clear the message from session after retrieving it
    unset($_SESSION['message']);
    unset($_SESSION['messageType']);
}

// Fetch current club data
$stmt = $conn->prepare("SELECT clubName, clubDescription, clubUsername, clubPassword FROM club WHERE clubID = ?");
$stmt->bind_param("i", $clubID);
$stmt->execute();
$result = $stmt->get_result();
$clubData = $result->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clubName = trim($_POST['clubName']);
    $clubDescription = trim($_POST['clubDescription']);
    $clubUsername = trim($_POST['clubUsername']);
    $clubPassword = trim($_POST['clubPassword']);
    
    // Validate input
    $errors = [];
    if (empty($clubName)) {
        $errors[] = "Club name is required";
    }
    if (strlen($clubName) > 255) {
        $errors[] = "Club name must be less than 255 characters";
    }
    if (strlen($clubDescription) > 100) {
        $errors[] = "Club description must be less than 100 characters";
    }
    if (strlen($clubUsername) > 25) {
        $errors[] = "Username must be less than 25 characters";
    }
    if (strlen($clubPassword) > 255) {
        $errors[] = "Password must be less than 255 characters";
    }

    if (empty($errors)) {
        // Update the database
        $sql = "UPDATE club SET 
                clubName = ?, 
                clubDescription = ?, 
                clubUsername = ?";
        $params = array($clubName, $clubDescription, $clubUsername);
        $types = "sss";
        
        // Debug line
        error_log("Updating club with ID: " . $clubID);
        
        if (!empty($clubPassword)) {
            $sql .= ", clubPassword = ?";
            $params[] = $clubPassword;
            $types .= "s";
        }
        
        $sql .= " WHERE clubID = ?";
        $params[] = $clubID;
        $types .= "i";
        
        // Debug lines
        error_log("SQL Query: " . $sql);
        error_log("Parameter types: " . $types);
        
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            error_log("Prepare failed: " . $conn->error);
            $_SESSION['message'] = 'Database prepare error: ' . $conn->error;
            $_SESSION['messageType'] = 'error';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit();
        }
        
        $stmt->bind_param($types, ...$params);
        if (!$stmt->execute()) {
            error_log("Execute failed: " . $stmt->error);
            $_SESSION['message'] = 'Database execute error: ' . $stmt->error;
            $_SESSION['messageType'] = 'error';
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit();
        }
        
        if ($stmt->affected_rows > 0) {
            // Update session data with new club information
            $refreshStmt = $conn->prepare("SELECT clubName, clubDescription, clubUsername FROM club WHERE clubID = ?");
            $refreshStmt->bind_param("i", $clubID);
            $refreshStmt->execute();
            $result = $refreshStmt->get_result();
            $updatedClubData = $result->fetch_assoc();
            
            // Update the session variables with new data
            $_SESSION['clubName'] = $updatedClubData['clubName'];
            $_SESSION['clubDescription'] = $updatedClubData['clubDescription'];
            $_SESSION['clubUsername'] = $updatedClubData['clubUsername'];
            
            $_SESSION['message'] = 'Profile updated successfully!';
            $_SESSION['messageType'] = 'success';
        } else {
            $_SESSION['message'] = 'No changes were made to the profile.';
            $_SESSION['messageType'] = 'warning';
        }
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
        // END OF REPLACEMENT SECTION
    } else {
        $_SESSION['message'] = 'Error updating profile. Please try again.';
        $_SESSION['messageType'] = 'error';
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Club Profile</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Base styles */
        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f0f2f5;
        }

        /* Main content area */
        main {
            margin-left: 200px;
            padding: 20px 40px;
            background-color: #f0f2f5;
        }

        /* Header section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 20px;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
            margin-bottom: 30px;
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            text-align: center;
        }

        /* Form container */
        form {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 0 auto;
        }

        /* Form elements */
        .form-group {
            margin-bottom: 25px;
            animation: fadeIn 0.5s ease-out forwards;
        }

        label {
            display: block;
            font-weight: 600;
            color: #1a365d;
            margin-bottom: 12px;
            font-size: 14px;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background-color: #f8fafc;
            box-sizing: border-box;
        }

        input:hover, textarea:hover {
            border-color: #90cdf4;
            background-color: #fff;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: #0061f2;
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.15);
            background-color: #fff;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        /* Alert messages */
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-success {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #6ee7b7;
        }

        .alert-danger {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fca5a5;
        }

        /* Submit button */
        .btn {
            background-color: #10b981;
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 20px;
            width: auto;
            display: inline-block;
            box-shadow: 0 2px 4px rgba(16, 185, 129, 0.1);
        }

        .btn:hover {
            background-color: #059669;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(16, 185, 129, 0.2);
        }

        .btn-secondary {
            background-color: #6b7280;
            margin-left: 10px;
        }

        .btn-secondary:hover {
            background-color: #4b5563;
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive design */
        @media (max-width: 1024px) {
            main {
                margin-left: 0;
                padding: 20px;
            }

            form {
                padding: 20px;
            }
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: #0061f2;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <?php include('club_sidebar.php'); ?>
    <main>
        <header class="header">
            <div class="header-section">
                <div class="welcome-card">
                    <div class="welcome-text">
                        <h1>Update Club Profile</h1>
                    </div>
                </div>
            </div>
        </header>
        
        <form method="POST" class="mt-4">
            <div class="form-group">
                <label for="clubName">Club Name</label>
                <input type="text" id="clubName" name="clubName" 
                       value="<?php echo htmlspecialchars($clubData['clubName']); ?>" required>
            </div>

            <div class="form-group">
                <label for="clubDescription">Club Description</label>
                <textarea id="clubDescription" name="clubDescription" 
                          rows="3"><?php echo htmlspecialchars($clubData['clubDescription']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="clubUsername">Username</label>
                <input type="text" id="clubUsername" name="clubUsername" 
                       value="<?php echo htmlspecialchars($clubData['clubUsername']); ?>" required>
            </div>

            <div class="form-group">
                <label for="clubPassword">New Password (leave blank to keep current)</label>
                <input type="password" id="clubPassword" name="clubPassword">
            </div>

            <button type="submit" class="btn">Update Profile</button>
        </form>
    </main>

    <?php if (!empty($message)): ?>
    <script>
        Swal.fire({
            title: <?php echo $messageType === 'success' ? '"Success!"' : '"Error"' ?>,
            text: <?php echo json_encode($message); ?>,
            icon: <?php echo json_encode($messageType); ?>,
            confirmButtonText: 'OK',
            confirmButtonColor: <?php echo $messageType === 'success' ? "'#10b981'" : "'#ef4444'" ?>
        })<?php if ($messageType === 'success'): ?>.then((result) => {
            if (result.isConfirmed) {
                // No need to reload since we're already on a fresh page load
                // Just clear the URL if it has any parameters
                if(window.location.search) {
                    window.history.replaceState({}, document.title, window.location.pathname);
                }
            }
        })<?php endif; ?>;
    </script>
<?php endif; ?>
</body>
</html>