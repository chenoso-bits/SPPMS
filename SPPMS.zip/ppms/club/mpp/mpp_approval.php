<?php
// Start session
session_start();

// Check if user is logged in as MPP
if (!isset($_SESSION['clubType']) || $_SESSION['clubType'] !== 'mpp') {
    echo "Unauthorized access! Please log in as MPP.";
    exit();
}

// Database connection
include('../../connection.php');

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle approval/rejection submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['paperwork_id'])) {
    $action = $_POST['action'];
    $paperworkId = $_POST['paperwork_id'];
    $status = ($action === 'approve') ? 'Diluluskan' : 'Ditolak';
    $remarks = isset($_POST['remarks']) ? $_POST['remarks'] : '';
    
    // Update paperwork status
    $updateSql = "UPDATE paperwork SET status = ?, remarks = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("ssi", $status, $remarks, $paperworkId);
    
    if ($updateStmt->execute()) {
        header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $paperworkId . "&message=Status updated successfully");
        exit();
    } else {
        header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $paperworkId . "&error=Failed to update status");
        exit();
    }
    $updateStmt->close();
}

// Check if paperwork ID is provided
if (isset($_GET['id'])) {
    $paperworkID = $_GET['id'];
    
    // Modified query to fetch paperwork details (no clubID restriction for MPP)
    $sql = "SELECT p.*, c.clubName 
            FROM paperwork p
            JOIN club c ON c.clubID = p.clubID 
            WHERE p.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $paperworkID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $paperwork = $result->fetch_assoc();
    } else {
        echo "Paperwork not found!";
        exit();
    }
    $stmt->close();
} else {
    echo "No paperwork ID provided!";
    exit();
}

// Sanitize and validate file paths (adjust validation rules as needed)
$tentativeFile = filter_var($paperwork['tentative_file'], FILTER_SANITIZE_URL);
$costFile = filter_var($paperwork['cost_file'], FILTER_SANITIZE_URL);

if (!empty($tentativeFile) && preg_match('/\.pdf$/i', $tentativeFile)) {
    $tentativeFileLink = htmlentities($tentativeFile);
}

if (!empty($costFile) && preg_match('/\.pdf$/i', $costFile)) {
    $costFileLink = htmlentities($costFile);
}

// Close the connection
$conn->close();

// SDG descriptions mapping
$sdgDescriptions = [
    "sdg1" => "SDG 1: Tiada Kemiskinan",
    "sdg2" => "SDG 2: Kelaparan Sifar",
    "sdg3" => "SDG 3: Kesihatan Baik dan Kesejahteraan",
    "sdg4" => "SDG 4: Pendidikan Berkualiti",
    "sdg5" => "SDG 5: Kesaksamaan Jantina",
    "sdg6" => "SDG 6: Air Bersih dan Sanitasi",
    "sdg7" => "SDG 7: Tenaga Berpatutan dan Bersih",
    "sdg8" => "SDG 8: Pekerjaan yang Layak dan Pertumbuhan Ekonomi",
    "sdg9" => "SDG 9: Industri, Inovasi dan Prasarana",
    "sdg10" => "SDG 10: Mengurangkan Ketidaksamaan",
    "sdg11" => "SDG 11: Bandar dan Masyarakat Mampan",
    "sdg12" => "SDG 12: Penggunaan dan Pengeluaran Bertanggungjawab",
    "sdg13" => "SDG 13: Tindakan terhadap Perubahan Iklim",
    "sdg14" => "SDG 14: Kehidupan Laut",
    "sdg15" => "SDG 15: Kehidupan di Darat",
    "sdg16" => "SDG 16: Keamanan, Keadilan dan Institusi yang Kuat",
    "sdg17" => "SDG 17: Kerjasama untuk Matlamat"
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Paperwork - MPP Approval</title>
    <link rel="stylesheet" href="club_homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        .main-content {
            padding: 30px;
            min-height: 100vh;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            max-width: 1200px;
            margin: 0 auto;
        }

        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .detail-item {
            padding: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
        }

        .detail-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .detail-item label {
            font-weight: 600;
            color: #495057;
            display: block;
            margin-bottom: 8px;
            font-size: 0.9em;
            text-transform: uppercase;
        }

        .detail-item a {
            color: #007bff;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: color 0.3s ease;
        }

        .detail-item a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .file-link {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            background-color: #007bff;
            color: white !important;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .file-link:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            text-decoration: none !important;
        }

        .file-link i {
            margin-right: 8px;
        }

        /* Responsive adjustments */
        @media (max-width: 1200px) {
            .details-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                margin-left: 0;
                padding: 15px;
            }
        }

        /* Header Section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 20px;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            text-align: center;
        }

        .role-text {
            margin: 10px 0 0 20px;
            font-size: 1.2em;
            opacity: 0.9;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* New styles for approval section */
        .approval-section {
            margin-top: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #dee2e6;
        }

        .approval-buttons {
            display: flex;
            gap: 15px;
            margin-top: 20px;
            justify-content: center;
        }

        .approve-btn, .reject-btn {
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .approve-btn {
            background-color: #28a745;
            color: white;
        }

        .reject-btn {
            background-color: #dc3545;
            color: white;
        }

        .approve-btn:hover, .reject-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .remarks-field {
            margin: 20px 0;
        }

        .remarks-field textarea {
            width: 96%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            min-height: 100px;
            margin-top: 8px;
        }

        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 4px;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .status-pending {
            background-color: #ffc107;
            color: #000;
        }

        .status-approved {
            background-color: #28a745;
            color: white;
        }

        .status-rejected {
            background-color: #dc3545;
            color: white;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <?php include("mpp_sidebar.php");?>
    <div class="content-wrapper">
        <!-- Welcome Section -->
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1>Paperwork Details</h1>
                </div>
            </div>
        </div>

        <!-- Add status messages -->
        <?php if (isset($_GET['message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_GET['message']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <div class="main-content">
            <div class="container">
                <div class="details-grid">
                    <div class="detail-item">
                        <label>Tajuk Kertas Kerja</label>
                        <?php echo htmlspecialchars($paperwork['program_name']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Intro</label>
                        <?php echo htmlspecialchars($paperwork['program_intro']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Background</label>
                        <?php echo htmlspecialchars($paperwork['program_background']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Objective</label>
                        <?php echo htmlspecialchars($paperwork['program_objective']); ?>
                    </div>
                    <div class="detail-item">
                        <label>SDG</label>
                        <?php echo isset($sdgDescriptions[$paperwork['sdg']]) ? htmlspecialchars($sdgDescriptions[$paperwork['sdg']]) : 'Unknown SDG'; ?>
                    </div>
                    <div class="detail-item">
                        <label>SDG Subcategory</label>
                        <?php echo htmlspecialchars($paperwork['sdg_subcategory']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Themes</label>
                        <?php echo htmlspecialchars($paperwork['program_themes']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Organization</label>
                        <?php echo htmlspecialchars($paperwork['program_org']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Start Date</label>
                        <?php echo htmlspecialchars($paperwork['start_date']); ?>
                    </div>
                    <div class="detail-item">
                        <label>End Date</label>
                        <?php echo htmlspecialchars($paperwork['end_date']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Start Time</label>
                        <?php echo htmlspecialchars($paperwork['start_time']); ?>
                    </div>
                    <div class="detail-item">
                        <label>End Time</label>
                        <?php echo htmlspecialchars($paperwork['end_time']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Target</label>
                        <?php echo htmlspecialchars($paperwork['program_target']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Overall Cost</label>
                        <?php echo htmlspecialchars($paperwork['overall_cost']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Logistical Needs</label>
                        <?php echo htmlspecialchars($paperwork['logistical_needs']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Additional Details</label>
                        <?php echo htmlspecialchars($paperwork['additional_details']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Tentative File</label>
                        <?php if (isset($tentativeFileLink)): ?>
                            <a href="<?php echo $tentativeFileLink; ?>" class="file-link" target="_blank">
                                <i class="fas fa-file-pdf"></i>
                                View Tentative PDF
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="detail-item">
                        <label>Cost File</label>
                        <?php if (isset($costFileLink)): ?>
                            <a href="<?php echo $costFileLink; ?>" class="file-link" target="_blank">
                                <i class="fas fa-file-pdf"></i>
                                View Cost PDF
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="detail-item">
                        <label>Tarikh Hantar</label>
                        <?php echo htmlspecialchars($paperwork['created_at']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Category</label>
                        <?php echo htmlspecialchars($paperwork['category']); ?>
                    </div>
                    
                    <!-- Add approval section -->
                    <div class="approval-section">
                        <h2>Approval Status</h2>
                        <div class="status-badge <?php 
                            echo isset($paperwork['status']) ? 
                                ($paperwork['status'] === 'Diluluskan' ? 'status-approved' : 
                                ($paperwork['status'] === 'Ditolak' ? 'status-rejected' : 'status-pending')) : 
                                'status-pending'; ?>">
                            <?php echo isset($paperwork['status']) ? htmlspecialchars($paperwork['status']) : 'Disemak'; ?>
                        </div>
                        
                        <?php if (!isset($paperwork['status']) || $paperwork['status'] === 'Disemak'): ?>
                            <form method="POST" action="">
                                <input type="hidden" name="paperwork_id" value="<?php echo $paperworkID; ?>">
                                
                                <div class="remarks-field">
                                    <label for="remarks"><strong>Remarks/Comments:</strong></label>
                                    <textarea name="remarks" id="remarks" required></textarea>
                                </div>
                                
                                <div class="approval-buttons">
                                    <button type="submit" name="action" value="approve" class="approve-btn">
                                        <i class="fas fa-check"></i> Approve
                                    </button>
                                    <button type="submit" name="action" value="reject" class="reject-btn">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="remarks-field">
                                <label><strong>Remarks/Comments:</strong></label>
                                <p><?php echo htmlspecialchars($paperwork['remarks'] ?? 'No remarks provided'); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>