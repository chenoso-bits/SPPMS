<?php
    // Start session
    session_start();

    if (!isset($_SESSION['clubID']) || !isset($_SESSION['clubDimension'])) {
        echo "Session for clubID or clubDimension is not set!";
        exit();
    }
    
    // Database connection
    include('../../connection.php');

    $clubID = $_SESSION['clubID'];
    $clubDimension = $_SESSION['clubDimension'];
    $clubName = $_SESSION['clubName'];

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT p.program_name, p.category, p.created_at, p.status, p.id
            FROM paperwork p 
            JOIN club c ON c.clubID = p.clubID
            WHERE c.clubID = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $clubID);
        $stmt->execute();
        $stmt->bind_result($programName, $category, $submissionDate, $status, $id);

        $paperwork = [];
        while ($stmt->fetch()) {
            $paperwork[] = [
                'programName' => $programName,
                'category'=> $category,
                'submissionDate' => $submissionDate,
                'status' => $status,
                'id' => $id
            ];
        }
        $stmt->close();
    } else {
        echo "Error preparing the SQL statement: " . $conn->error;
        exit();
    }

    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Dashboard</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-bootstrap-4/bootstrap-4.css">
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <?php include('mpp_sidebar.php'); ?>
    
    <div class="content-wrapper">
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1>Welcome, <?php echo htmlspecialchars($clubName); ?>!</h1>
                    <p class="dimension-text">TUAH Dimension: <strong><?php echo htmlspecialchars($clubDimension)?></strong></p>
                </div>
                <div class="quick-stats">
                    <div class="stat-card">
                        <i class="fas fa-file-alt"></i>
                        <div class="stat-info">
                            <span class="stat-number"><?php echo count($paperwork); ?></span>
                            <span class="stat-label">Total Paperwork</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-content">
            <div class="paperwork-section">
                <div class="section-header">
                    <h2><i class="fas fa-clipboard-list"></i> Paperwork List</h2>
                </div>
                <div class="table-container">
                    <table id="paperworkTable" class="display responsive nowrap">
                        <thead>
                            <tr>
                                <th>Paperwork Title</th>
                                <th>Category</th>
                                <th>Submission Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($paperwork)): ?>
                                <?php foreach ($paperwork as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['programName']); ?></td>
                                        <td><?php echo htmlspecialchars($item['category']); ?></td>
                                        <td><?php echo htmlspecialchars($item['submissionDate']); ?></td>
                                        <td>
                                            <span class="status-badge <?php echo strtolower(htmlspecialchars($item['status'])); ?>">
                                                <?php echo htmlspecialchars($item['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if (strtolower($item['status']) !== 'diluluskan'): ?>
                                                <a href="mpp_update_paperwork.php?id=<?php echo htmlspecialchars($item['id']); ?>" 
                                                class="action-btn">
                                                    <i class="fas fa-edit"></i> Update
                                                </a>
                                                <button onclick="deletePaperwork(<?php echo htmlspecialchars($item['id']); ?>, '<?php echo htmlspecialchars(addslashes($item['programName'])); ?>', '<?php echo htmlspecialchars($item['status']); ?>')" 
                                                        class="action-btn delete-btn">
                                                    <i class="fas fa-trash-alt"></i> Delete
                                                </button>
                                                <a href="mpp_view_paperwork.php?id=<?php echo htmlspecialchars($item['id']); ?>" 
                                                class="action-btn view-btn">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            <?php else: ?>
                                                <button class="action-btn disabled" disabled title="Cannot modify approved paperwork">
                                                    <i class="fas fa-edit"></i> Update
                                                </button>
                                                <button class="action-btn delete-btn disabled" disabled title="Cannot delete approved paperwork">
                                                    <i class="fas fa-trash-alt"></i> Delete
                                                </button>
                                                <a href="mpp_view_paperwork.php?id=<?php echo htmlspecialchars($item['id']); ?>" 
                                                class="action-btn view-btn">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Base Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f0f2f5;
            color: #333;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* Header Section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 30px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: -10px 0 0 20px;
            font-size: 40px;
            font-weight: 600;
        }

        .dimension-text {
            margin: 5px 0 0 20px; 
            opacity: 0.9;
            font-size: 20px;
        }

        /* Quick Stats */
        .quick-stats {
            display: flex;
            gap: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px 25px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-card i {
            font-size: 24px;
        }

        .stat-info {
            display: flex;
            flex-direction: column;
        }

        .stat-number {
            font-size: 24px;
            font-weight: 600;
        }

        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 50px;
            padding-top: 20px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .section-header h2 {
            margin: 0;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .new-paperwork-btn {
            background: #00a6f9;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .new-paperwork-btn:hover {
            background: #0061f2;
            transform: translateY(-2px);
        }

        /* Table Styles */
        .table-container {
            margin-top: 20px;
        }

        #paperworkTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        #paperworkTable th {
            background: #007bff;
            padding: 15px;
            font-weight: 600;
            color:rgb(255, 255, 255);
            border-bottom: 2px solid #e9ecef;
        }

        #paperworkTable td {
            padding: 15px 10px;
            font-size: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        /* Status Badges */
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .status-badge.dihantar {
            background-color: #fff8f1;
            color: #fd7e14;
        }

        .status-badge.disemak {
            background-color: #e8f4fd;
            color: #0d6efd;
        }

        .status-badge.diluluskan {
            background-color: #e8f8f5;
            color: #20c997;
        }

        /* Action Button */
        .action-btn {
            background: #e8f4fd;
            color: #0d6efd;
            padding: 6px 12px; /* Reduced padding */
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9em;
            display: inline-flex;
            align-items: center;
            gap: 4px; /* Reduced gap */
            transition: all 0.2s ease;
            margin: 0 2px; /* Added small margin */
        }

        .action-btn.view-btn {
            background: #e8f5e9;
            color: #2e7d32;
            margin-left: 2px; /* Reduced margin */
            margin-right: 2px; /* Reduced margin */
        }

        .action-btn.view-btn:hover {
            background: #2e7d32;
            color: white;
        }

        .action-btn:hover {
            background: #0d6efd;
            color: white;
        }

        .action-btn.disabled {
            background-color: #e8f4fd;
            color: #0d6efd;
            box-shadow: none;
            border: none;
            cursor: not-allowed;
            pointer-events: none;
            opacity: 0.5;
        }

        .action-btn.delete-btn.disabled {
            background-color: #fee2e2;
            color: #ef4444;
            opacity: 0.5;
        }

        /* DataTables Custom Styling */
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin-bottom: 10px;
        }

        .dataTables_wrapper .dataTables_filter input {
            width: 200px;
            margin-left: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin: 0 4px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #0061f2;
            border-color: #0061f2;
            color: white !important;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .content-wrapper {
                margin-left: 0;
            }

            .welcome-card {
                flex-direction: column;
                text-align: center;
                gap: 20px;
            }

            .quick-stats {
                justify-content: center;
            }
        }

        @media (max-width: 768px) {
            .section-header {
                flex-direction: column;
                gap: 15px;
            }

            .new-paperwork-btn {
                width: 100%;
                justify-content: center;
            }

            .dataTables_wrapper .dataTables_filter input {
                width: 150px;
            }
        }

        .action-btn.delete-btn {
            background: #fee2e2;
            color: #dc2626;
            margin-left: 2px; /* Reduced margin */
            margin-right: 2px; /* Reduced margin */
            border: 0;
        }

        .action-btn.delete-btn:hover {
            background: #dc2626;
            color: white;
        }

        /* Add space between buttons on mobile */
        @media (max-width: 768px) {
            .action-btn {
                margin-bottom: 4px; /* Reduced margin */
                margin-right: 2px; /* Added small margin */
            }
        }
    </style>

<script>
        $(document).ready(function() {
            $('#paperworkTable').DataTable({
                responsive: true,
                pageLength: 10,
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "«",
                        last: "»",
                        next: "→",
                        previous: "←"
                    }
                },
                columnDefs: [{
                    targets: -1,
                    orderable: false
                }],
                order: [[2, 'desc']]
            });
        });

        function deletePaperwork(id, programName, status) {
        // Check if status is 'Diluluskan'
        if (status.toLowerCase() === 'diluluskan') {
            Swal.fire({
                title: 'Action Not Allowed',
                text: 'Approved paperwork cannot be deleted.',
                icon: 'warning',
                confirmButtonColor: '#0061f2'
            });
            return;
        }

        Swal.fire({
            title: 'Delete Paperwork?',
            html: `Are you sure you want to delete <strong>${programName}</strong>?<br>This action cannot be undone.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc2626',
            cancelButtonColor: '#6b7280',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading state
                Swal.fire({
                    title: 'Deleting...',
                    text: 'Please wait',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    willOpen: () => {
                        Swal.showLoading();
                    }
                });

                $.ajax({
                    url: 'mpp_delete_paperwork.php',
                    type: 'POST',
                    data: {
                        id: id
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Server response:', response); // Debug log
                        
                        if (response.status === 'success') {
                            Swal.fire({
                                title: 'Deleted!',
                                text: response.message || 'The paperwork has been deleted.',
                                icon: 'success',
                                confirmButtonColor: '#0061f2'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: response.message || 'Failed to delete paperwork',
                                icon: 'error',
                                confirmButtonColor: '#0061f2'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Ajax error:', {
                            status: status,
                            error: error,
                            response: xhr.responseText
                        });
                        
                        Swal.fire({
                            title: 'Error!',
                            text: 'Something went wrong while deleting the paperwork. Please try again.',
                            icon: 'error',
                            confirmButtonColor: '#0061f2'
                        });
                    }
                });
            }
        });
    }
    </script>
</body>
</html>