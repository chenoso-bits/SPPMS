<?php
    // Start session
    session_start();

    if (!isset($_SESSION['clubID'])) {
        header("Location: ../club_login.php");
        exit();
    }
    
    // Database connection
    include('../../connection.php');

    // Check if the connection is successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the logged-in club is an MPP club
    $clubCheckSql = "SELECT clubType FROM club WHERE clubID = ?";
    $clubCheckStmt = $conn->prepare($clubCheckSql);
    $clubCheckStmt->bind_param("i", $_SESSION['clubID']);
    $clubCheckStmt->execute();
    $clubResult = $clubCheckStmt->get_result();
    $clubData = $clubResult->fetch_assoc();

    if ($clubData['clubType'] !== 'mpp') {
        header("Location: ../unauthorized.php");
        exit();
    }

    // Initialize filter values
    $searchTitle = $_GET['searchTitle'] ?? '';
    $searchDate = $_GET['searchDate'] ?? '';
    $searchStatus = $_GET['searchStatus'] ?? '';

    // Query to fetch past JPM paperwork (Approved and Rejected)
    $sql = "SELECT p.program_name, p.created_at, p.status, p.id, c.clubName 
            FROM paperwork p
            JOIN club c ON p.clubID = c.clubID 
            WHERE p.category = 'JPM' 
            AND p.status IN ('Diluluskan', 'Ditolak')
            AND p.program_name LIKE ? 
            AND p.created_at LIKE ? 
            AND (? = '' OR p.status LIKE ?)";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $likeTitle = "%$searchTitle%";
    $likeDate = "%$searchDate%";
    $likeStatus = "%$searchStatus%";
    $stmt->bind_param("ssss", $likeTitle, $likeDate, $searchStatus, $likeStatus);

    // Execute the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch paperwork
    $paperwork = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $paperwork[] = [
                'programName' => $row['program_name'],
                'submissionDate' => $row['created_at'],
                'status' => $row['status'],
                'id' => $row['id'],
                'clubName' => $row['clubName']
            ];
        }
    }

    $stmt->close();
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MPP Past JPM Paperwork</title>
    <link rel="stylesheet" href="club_homepage.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
</head>
<body>
    <?php include('mpp_sidebar.php'); ?>
    
    <main class="content-wrapper">
        <!-- Header Section -->
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1>Past JPM Paperwork</h1>
                    <p class="subtitle">View all approved and rejected JPM paperwork submissions</p>
                </div>
                <div class="quick-stats">
                    <div class="stat-card">
                        <i class="fas fa-check-circle"></i>
                        <div class="stat-info">
                            <span class="stat-number">
                                <?php 
                                    echo count(array_filter($paperwork, function($p) {
                                        return $p['status'] === 'Diluluskan';
                                    })); 
                                ?>
                            </span>
                            <span class="stat-label">Approved</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-times-circle"></i>
                        <div class="stat-info">
                            <span class="stat-number">
                                <?php 
                                    echo count(array_filter($paperwork, function($p) {
                                        return $p['status'] === 'Ditolak';
                                    })); 
                                ?>
                            </span>
                            <span class="stat-label">Rejected</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-content">
            <!-- Filter Section -->
            <div class="filter-card">
                <div class="card-header">
                    <h2><i class="fas fa-filter"></i> Filter Options</h2>
                </div>
                <div class="card-body">
                    <form method="GET" action="" class="filter-form">
                        <div class="form-group">
                            <label for="searchTitle">
                                <i class="fas fa-heading"></i> Program Name
                            </label>
                            <input type="text" id="searchTitle" name="searchTitle" 
                                   value="<?php echo htmlspecialchars($searchTitle); ?>"
                                   placeholder="Enter paperwork title">
                        </div>

                        <div class="form-group">
                            <label for="searchDate">
                                <i class="fas fa-calendar-alt"></i> Submission Date
                            </label>
                            <input type="date" id="searchDate" name="searchDate" 
                                   value="<?php echo htmlspecialchars($searchDate); ?>">
                        </div>

                        <div class="form-group">
                            <label for="searchStatus">
                                <i class="fas fa-info-circle"></i> Status
                            </label>
                            <select id="searchStatus" name="searchStatus">
                                <option value="">All Status</option>
                                <option value="Diluluskan" <?php echo $searchStatus == 'Diluluskan' ? 'selected' : ''; ?>>Diluluskan</option>
                                <option value="Ditolak" <?php echo $searchStatus == 'Ditolak' ? 'selected' : ''; ?>>Ditolak</option>
                            </select>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn-primary">
                                <i class="fas fa-search"></i> Apply Filter
                            </button>
                            <button type="button" onclick="window.location.href='mpp_jpm_past.php'" class="btn-secondary">
                                <i class="fas fa-undo"></i> Reset
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Past Paperwork Section -->
            <div class="paperwork-card">
                <div class="card-header">
                    <h2><i class="fas fa-history"></i> Past JPM Paperwork</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="pastPaperworkTable" class="display responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Program Name</th>
                                    <th>Club Name</th>
                                    <th>Submission Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($paperwork as $paper): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($paper['programName']); ?></td>
                                    <td><?php echo htmlspecialchars($paper['clubName']); ?></td>
                                    <td><?php echo htmlspecialchars($paper['submissionDate']); ?></td>
                                    <td><span class="status <?php echo htmlspecialchars($paper['status']); ?>">
                                        <?php echo htmlspecialchars($paper['status']); ?>
                                    </span></td>
                                    <td>
                                        <a href="mpp_view_paperwork.php?id=<?php echo $paper['id']; ?>" class="btn-small view-btn">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <script>
        $(document).ready(function() {
            $('#pastPaperworkTable').DataTable({
                responsive: true,
                pageLength: 10,
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'excel',
                        text: 'Export to Excel',
                        filename: 'Past_JPM_Paperwork',
                        title: 'Past JPM Paperwork'
                    }
                ],
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "«",
                        last: "»",
                        next: "→",
                        previous: "←"
                    },
                    emptyTable: "No paperwork found"
                },
                columnDefs: [{
                    targets: -1,
                    orderable: false
                }],
                order: [[2, 'desc']]
            });
        });
    </script>

<style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f0f2f5;
            color: #333;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            min-height: 100vh;
        }

        main {
            margin-left: 250px;
            padding: 20px;
        }

        /* Header Section */
        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 30px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 600;
            margin-left: 20px;
        }

        .subtitle {
            margin: 10px 0 0;
            opacity: 0.9;
            font-size: 1.1rem;
            margin-left: 20px;
        }

        /* Quick Stats */
        .quick-stats {
            display: flex;
            gap: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px 25px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* Adjust card padding */
        .filter-card .card-body {
            padding: 20px;  /* Reduced padding */
        }

        /* Make form actions responsive */
        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .form-actions {
                width: 100%;
                justify-content: flex-end;
            }
        }

        /* Cards */
        .filter-card, .paperwork-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            padding-left: 20px;
        }

        .card-header {
            padding: 20px 30px;
            border-bottom: 1px solid #e9ecef;
        }

        .card-header h2 {
            margin: 0;
            font-size: 1.25rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .card-body {
            padding: 30px;
        }

        /* Filter Form */
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: flex-end;  /* Align items to bottom */
            margin-left: 10px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
            margin-bottom: 0;  /* Remove bottom margin */
        }

        .form-group label {
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 0;  /* Remove bottom margin */
        }

        .form-group input,
        .form-group select {
            padding: 8px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            align-items: flex-end;  /* Align with other elements */
            margin-left: 130px;
        }

        /* Buttons */
        .btn-primary, .btn-secondary {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: #0061f2;
            color: white;
        }

        .btn-secondary {
            background: #e9ecef;
            color: #495057;
        }

        .btn-primary:hover {
            background: #0056b3;
        }

        .btn-secondary:hover {
            background: #dee2e6;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .content-wrapper {
                margin-left: 0;
            }

            .welcome-card {
                flex-direction: column;
                text-align: center;
                gap: 20px;
            }

            .quick-stats {
                flex-direction: row;
                justify-content: center;
            }
        }

        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }

            .stat-card {
                flex-direction: column;
                text-align: center;
                padding: 15px;
            }
        }

        .dashboard-container {
            display: flex;
            gap: 20px;
            align-items: flex-start;
        }

        /* Filter Section Styling */
        .filter-section {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 30px;
            width: 250px;
        }

        .filter-section h2 {
            margin: 0 0 20px 0;
            font-size: 20px;
            color: #333;
        }

        .filter-section form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .filter-section label {
            font-weight: 500;
            color: #555;
        }

        .filter-section input,
        .filter-section select {
            padding: 10px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            width: 100%;
        }

        .filter-section button {
            background: #0061f2;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filter-section button:hover {
            background: #0056b3;
        }

        .clear-filter-btn {
            background: #6c757d !important;
        }

        /* Dashboard Section Styling */
        .dashboard {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 30px;
            flex-grow: 1;
        }

        .dashboard h2 {
            margin: 0 0 20px 0;
            font-size: 20px;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-bottom: 30px;
        }

        th {
            background: #0061f2;
            color: white;
            padding: 15px;
            font-weight: 600;
            text-align: left;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
        }

        /* Status Styling */
        .status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .status.Dihantar {
            background-color: #fff8f1;
            color: #fd7e14;
        }

        .status.Disemak {
            background-color: #e8f4fd;
            color: #0d6efd;
        }

        .status.Diluluskan {
            background-color: #e8f8f5;
            color: #20c997;
        }

        /* Button Styling */
        .btn-small {
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.9em;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin: 0 2px;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .view-btn {
            background: #e8f5e9;
            color: #2e7d32;
        }

        .view-btn:hover {
            background: #2e7d32;
            color: white;
        }

        .archive-btn {
            background: #fee2e2;
            color: #dc2626;
        }

        .archive-btn:hover {
            background: #dc2626;
            color: white;
        }

        .unarchive-btn {
            background: #e8f8f5;
            color: #20c997;
        }

        .unarchive-btn:hover {
            background: #20c997;
            color: white;
        }

        /* DataTables Styling */
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin-bottom: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #0061f2;
            border-color: #0061f2;
            color: white !important;
        }

        /* Export Button Styling */
        .dt-buttons .dt-button {
            background: #20c997 !important;
            color: white !important;
            border: none !important;
            padding: 8px 16px !important;
            border-radius: 6px !important;
            margin-bottom: 15px;
        }

        .dt-buttons .dt-button:hover {
            background: #1ca883 !important;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            main {
                margin-left: 0;
            }

            .dashboard-container {
                flex-direction: column;
            }

            .filter-section {
                width: auto;
            }
        }

        @media (max-width: 768px) {
            .btn-small {
                margin-bottom: 4px;
            }
        }

        /* Status Styling for Past Paperwork */
        .status.Diluluskan {
            background-color: #e8f8f5;
            color: #20c997;
        }

        .status.Ditolak {
            background-color: #fee2e2;
            color: #dc2626;
        }
    </style>
</body>
</html>