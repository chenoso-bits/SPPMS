<?php
// Start session
session_start();

if (!isset($_SESSION['clubID'])) {
    header("Location: ../club_login.php");
    exit();
}

// Database connection
include('../../connection.php');

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if paperwork ID is provided
if (isset($_GET['id'])) {
    $paperworkID = $_GET['id'];

    // First check if the logged-in club is MPP
    $clubCheckSql = "SELECT clubType FROM club WHERE clubID = ? AND clubType = 'mpp'";
    $clubCheckStmt = $conn->prepare($clubCheckSql);
    $clubCheckStmt->bind_param("i", $_SESSION['clubID']);
    $clubCheckStmt->execute();
    $clubResult = $clubCheckStmt->get_result();
    $isMPP = ($clubResult->num_rows > 0);
    
    // Query to get paperwork details - different for MPP and regular clubs
    if ($isMPP) {
        // MPP can view any club's paperwork
        $sql = "SELECT p.*, c.clubName 
                FROM paperwork p
                JOIN club c ON c.clubID = p.clubID 
                WHERE p.id = ?";
    } else {
        // Regular clubs can only view their own paperwork
        $sql = "SELECT p.*, c.clubName 
                FROM paperwork p
                JOIN club c ON c.clubID = p.clubID 
                WHERE p.id = ? 
                AND p.clubID = ?
                AND p.status IN ('Diluluskan', 'Ditolak')";
    }
            
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        if ($isMPP) {
            $stmt->bind_param("i", $paperworkID);
        } else {
            $stmt->bind_param("ii", $paperworkID, $_SESSION['clubID']);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $paperwork = $result->fetch_assoc();
        } else {
            die("Paperwork not found or unauthorized access!");
        }
        $stmt->close();
    } else {
        die("Error preparing statement: " . $conn->error);
    }
} else {
    die("No paperwork ID provided!");
}

// Sanitize and validate file paths
$tentativeFile = filter_var($paperwork['tentative_file'], FILTER_SANITIZE_URL);
$costFile = filter_var($paperwork['cost_file'], FILTER_SANITIZE_URL);

if (!empty($tentativeFile)) {
    $tentativeFileLink = htmlspecialchars($tentativeFile);
}

if (!empty($costFile)) {
    $costFileLink = htmlspecialchars($costFile);
}

// Sanitize and validate file paths
$tentativeFile = filter_var($paperwork['tentative_file'], FILTER_SANITIZE_URL);
$costFile = filter_var($paperwork['cost_file'], FILTER_SANITIZE_URL);

if (!empty($tentativeFile) && preg_match('/\.pdf$/i', $tentativeFile)) {
    $tentativeFileLink = htmlspecialchars($tentativeFile);
}

if (!empty($costFile) && preg_match('/\.pdf$/i', $costFile)) {
    $costFileLink = htmlspecialchars($costFile);
}

// SDG descriptions mapping
$sdgDescriptions = [
    "sdg1" => "SDG 1: Tiada Kemiskinan",
    "sdg2" => "SDG 2: Kelaparan Sifar",
    "sdg3" => "SDG 3: Kesihatan Baik dan Kesejahteraan",
    "sdg4" => "SDG 4: Pendidikan Berkualiti",
    "sdg5" => "SDG 5: Kesaksamaan Jantina",
    "sdg6" => "SDG 6: Air Bersih dan Sanitasi",
    "sdg7" => "SDG 7: Tenaga Berpatutan dan Bersih",
    "sdg8" => "SDG 8: Pekerjaan yang Layak dan Pertumbuhan Ekonomi",
    "sdg9" => "SDG 9: Industri, Inovasi dan Prasarana",
    "sdg10" => "SDG 10: Mengurangkan Ketidaksamaan",
    "sdg11" => "SDG 11: Bandar dan Masyarakat Mampan",
    "sdg12" => "SDG 12: Penggunaan dan Pengeluaran Bertanggungjawab",
    "sdg13" => "SDG 13: Tindakan terhadap Perubahan Iklim",
    "sdg14" => "SDG 14: Kehidupan Laut",
    "sdg15" => "SDG 15: Kehidupan di Darat",
    "sdg16" => "SDG 16: Keamanan, Keadilan dan Institusi yang Kuat",
    "sdg17" => "SDG 17: Kerjasama untuk Matlamat"
];

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Past Paperwork - MPP</title>
    <link rel="stylesheet" href="club_homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        .main-content {
            padding: 30px;
            min-height: 100vh;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            max-width: 1200px;
            margin: 0 auto;
        }

        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .detail-item {
            padding: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
        }

        .detail-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .detail-item label {
            font-weight: 600;
            color: #495057;
            display: block;
            margin-bottom: 8px;
            font-size: 0.9em;
            text-transform: uppercase;
        }

        .detail-item a {
            color: #007bff;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: color 0.3s ease;
        }

        .detail-item a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

        .file-link {
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            background-color: #007bff;
            color: white !important;
            border-radius: 6px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .file-link:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            text-decoration: none !important;
        }

        .file-link i {
            margin-right: 8px;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 20px;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            text-align: center;
        }

        .club-info {
            background-color: #e8f4fd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .club-info h3 {
            margin: 0;
            color: #0d6efd;
            font-size: 1.1em;
        }

        .status-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            text-align: center;
            margin-top: 10px;
        }

        .status-Diluluskan {
            background-color: #e8f8f5;
            color: #20c997;
        }

        .status-Ditolak {
            background-color: #fee2e2;
            color: #dc2626;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            background-color: #6c757d;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .back-button:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .back-button i {
            margin-right: 8px;
        }

        .download-all-btn {
            display: inline-flex;
            align-items: center;
            padding: 10px 20px;
            background-color: #0061f2;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .download-all-btn:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
        }

        @media (max-width: 1200px) {
            .details-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .content-wrapper {
                margin-left: 0;
                padding: 15px;
            }
            
            .main-content {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include("mpp_sidebar.php");?>
    <div class="content-wrapper">
        <!-- Header Section -->
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1>Past Paperwork Details</h1>
                    <div class="club-info">
                        <h3>Club: <?php echo htmlspecialchars($paperwork['clubName']); ?></h3>
                        <div class="status-badge status-<?php echo htmlspecialchars($paperwork['status']); ?>">
                            Status: <?php echo htmlspecialchars($paperwork['status']); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-content">
            <div class="action-buttons">
                <a href="mpp_jpm_past.php" class="back-button">
                    <i class="fas fa-arrow-left"></i> Back to Past Paperwork
                </a>
                <?php if (isset($tentativeFileLink) && isset($costFileLink)): ?>
                <a href="#" onclick="window.open('<?php echo $tentativeFileLink; ?>'); window.open('<?php echo $costFileLink; ?>'); return false;" 
                   class="download-all-btn">
                    <i class="fas fa-download"></i> Open All Documents
                </a>
                <?php endif; ?>
            </div>

            <div class="container">
                <div class="details-grid">
                    <div class="detail-item">
                        <label>Tajuk Kertas Kerja</label>
                        <?php echo htmlspecialchars($paperwork['program_name']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Intro</label>
                        <?php echo htmlspecialchars($paperwork['program_intro']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Background</label>
                        <?php echo htmlspecialchars($paperwork['program_background']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Objective</label>
                        <?php echo htmlspecialchars($paperwork['program_objective']); ?>
                    </div>
                    <div class="detail-item">
                        <label>SDG</label>
                        <?php echo isset($sdgDescriptions[$paperwork['sdg']]) ? htmlspecialchars($sdgDescriptions[$paperwork['sdg']]) : 'Unknown SDG'; ?>
                    </div>
                    <div class="detail-item">
                        <label>SDG Subcategory</label>
                        <?php echo htmlspecialchars($paperwork['sdg_subcategory']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Themes</label>
                        <?php echo htmlspecialchars($paperwork['program_themes']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Organization</label>
                        <?php echo htmlspecialchars($paperwork['program_org']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Start Date</label>
                        <?php echo htmlspecialchars($paperwork['start_date']); ?>
                    </div>
                    <div class="detail-item">
                        <label>End Date</label>
                        <?php echo htmlspecialchars($paperwork['end_date']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Start Time</label>
                        <?php echo htmlspecialchars($paperwork['start_time']); ?>
                    </div>
                    <div class="detail-item">
                        <label>End Time</label>
                        <?php echo htmlspecialchars($paperwork['end_time']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Program Target</label>
                        <?php echo htmlspecialchars($paperwork['program_target']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Overall Cost</label>
                        <?php echo htmlspecialchars($paperwork['overall_cost']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Logistical Needs</label>
                        <?php echo htmlspecialchars($paperwork['logistical_needs']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Additional Details</label>
                        <?php echo htmlspecialchars($paperwork['additional_details']); ?>
                    </div>
                    <div class="detail-item">
                        <label>Tentative File</label>
                        <?php if ($paperwork['tentative_file']): ?>
                            <a href="view_file.php?id=<?php echo $paperworkID; ?>&type=tentative" class="file-link" target="_blank">
                                <i class="fas fa-file-pdf"></i>
                                View Tentative PDF
                            </a>
                        <?php else: ?>
                            <span>No file uploaded</span>
                        <?php endif; ?>
                    </div>
                    <div class="detail-item">
                        <label>Cost File</label>
                        <?php if ($paperwork['cost_file']): ?>
                            <a href="view_file.php?id=<?php echo $paperworkID; ?>&type=cost" class="file-link" target="_blank">
                                <i class="fas fa-file-pdf"></i>
                                View Cost PDF
                            </a>
                        <?php else: ?>
                            <span>No file uploaded</span>
                        <?php endif; ?>
                    </div>
                    <div class="detail-item">
                        <label>Tarikh Hantar</label>
                        <?php echo htmlspecialchars($paperwork['created_at']); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add any necessary JavaScript here
        document.addEventListener('DOMContentLoaded', function() {
            // You can add any initialization code here if needed
        });
    </script>
</body>
</html>