<?php
    // Start session
    session_start();

    if (!isset($_SESSION['clubID']) || !isset($_SESSION['clubDimension'])) {
        echo "Session for clubID or clubDimension is not set!";
        exit();
    }

    // Database connection (Replace with your actual database credentials)
    include('../../connection.php');

    // Assume 'club_id' is stored in session after login
    $clubID = $_SESSION['clubID'];
    $clubDimension = $_SESSION['clubDimension'];
    $clubName = $_SESSION['clubName'];

    // Check if the connection is successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Query to fetch student details assigned to the club
    $sql = "SELECT s.name, s.student_number, s.faculty, s.year_of_education, s.semester, cm.role
            FROM students s
            JOIN club_members cm ON cm.student_id = s.student_id
            JOIN club c ON c.clubID = cm.clubID
            WHERE c.clubID = ?";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters
        $stmt->bind_param("i", $clubID);
        
        // Execute the statement
        $stmt->execute();
        
        // Bind result variables
        $stmt->bind_result($name, $studentNumber, $faculty, $yearOfEducation, $semester, $role);

        // Fetch the results
        $members = [];
        while ($stmt->fetch()) {
            $members[] = [
                'name' => $name,
                'studentNumber' => $studentNumber,
                'faculty' => $faculty,
                'yearOfEducation' => $yearOfEducation,
                'semester' => $semester,
                'role' => $role
            ];
        }
        $stmt->close();
    } else {
        echo "Error preparing the SQL statement: " . $conn->error;
        exit();
    }
    
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Members</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
</head>
<body>
    <?php include('mpp_sidebar.php'); ?>
    
    <div class="content-wrapper">
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1><?php echo htmlspecialchars($clubName); ?> Members</h1>
                    <p class="dimension-text">TUAH Dimension: <strong><?php echo htmlspecialchars($clubDimension)?></strong></p>
                </div>
                <div class="quick-stats">
                    <div class="stat-card">
                        <i class="fas fa-users"></i>
                        <div class="stat-info">
                            <span class="stat-number"><?php echo count($members); ?></span>
                            <span class="stat-label">Total Members</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-content">
            <div class="members-section">
                <div class="section-header">
                    <h2><i class="fas fa-user-friends"></i> Club Members List</h2>
                </div>
                <div class="table-container">
                    <table id="membersTable" class="display responsive nowrap">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Student Number</th>
                                <th>Faculty</th>
                                <th>Year</th>
                                <th>Semester</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($members)): ?>
                                <?php foreach ($members as $member): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($member['name']); ?></td>
                                        <td><?php echo htmlspecialchars($member['studentNumber']); ?></td>
                                        <td><?php echo htmlspecialchars($member['faculty']); ?></td>
                                        <td><?php echo htmlspecialchars($member['yearOfEducation']); ?></td>
                                        <td><?php echo htmlspecialchars($member['semester']); ?></td>
                                        <td>
                                            <span class="role-badge <?php echo strtolower(htmlspecialchars($member['role'])); ?>">
                                                <?php echo htmlspecialchars($member['role']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Base Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f0f2f5;
            color: #333;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* Header Section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 30px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: -10px 0 0 20px;
            font-size: 40px;
            font-weight: 600;
        }

        .dimension-text {
            margin: 5px 0 0 20px;
            opacity: 0.9;
            font-size: 20px;
        }

        /* Quick Stats */
        .quick-stats {
            display: flex;
            gap: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px 25px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stat-card i {
            font-size: 24px;
        }

        .stat-info {
            display: flex;
            flex-direction: column;
        }

        .stat-number {
            font-size: 24px;
            font-weight: 600;
        }

        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 50px;
            padding-top: 20px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .section-header h2 {
            margin: 0;
            font-size: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Table Styles */
        .table-container {
            margin-top: 20px;
        }

        #membersTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        #membersTable th {
            background: #007bff;
            padding: 15px;
            font-weight: 600;
            color: rgb(255, 255, 255);
            border-bottom: 2px solid #e9ecef;
        }

        #membersTable td {
            padding: 15px;
            font-size: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        /* Role Badges */
        .role-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .role-badge.president {
            background-color: #fff8f1;
            color: #fd7e14;
        }

        .role-badge.member {
            background-color: #e8f4fd;
            color: #0d6efd;
        }

        .role-badge.secretary {
            background-color: #e8f8f5;
            color: #20c997;
        }

        /* DataTables Custom Styling */
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin-bottom: 10px;
        }

        .dataTables_wrapper .dataTables_filter input {
            width: 200px;
            margin-left: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin: 0 4px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #0061f2;
            border-color: #0061f2;
            color: white !important;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .content-wrapper {
                margin-left: 0;
            }

            .welcome-card {
                flex-direction: column;
                text-align: center;
                gap: 20px;
            }

            .quick-stats {
                justify-content: center;
            }
        }

        @media (max-width: 768px) {
            .section-header {
                flex-direction: column;
                gap: 15px;
            }

            .dataTables_wrapper .dataTables_filter input {
                width: 150px;
            }
        }
    </style>

    <script>
        $(document).ready(function() {
            $('#membersTable').DataTable({
                responsive: true,
                pageLength: 10,
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "«",
                        last: "»",
                        next: "→",
                        previous: "←"
                    }
                },
                columnDefs: [{
                    targets: -1,
                    orderable: false
                }],
                order: [[0, 'asc']],
                drawCallback: function(settings) {
                    $('.role-badge').addClass('animate__animated animate__fadeIn');
                }
            });
        });
    </script>
</body>
</html>