<?php
session_start();
include('..\..\connection.php');

$clubID = $_SESSION['clubID'];

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize form inputs
    $programName = mysqli_real_escape_string($conn, $_POST['programName']);
    $programIntro = mysqli_real_escape_string($conn, $_POST['programIntro']);
    $programBackground = mysqli_real_escape_string($conn, $_POST['programBackground']);
    $programObjective = mysqli_real_escape_string($conn, $_POST['programObjective']);
    $sdg = mysqli_real_escape_string($conn, $_POST['sdg']);
    $sdgSubcategory = mysqli_real_escape_string($conn, $_POST['sdgSubcategory']);
    $programThemes = mysqli_real_escape_string($conn, $_POST['programThemes']);
    $programOrg = mysqli_real_escape_string($conn, $_POST['programOrg']);
    $programTarget = mysqli_real_escape_string($conn, $_POST['programTarget']);
    $startDate = mysqli_real_escape_string($conn, $_POST['startDate']);
    $endDate = mysqli_real_escape_string($conn, $_POST['endDate']);
    $startTime = mysqli_real_escape_string($conn, $_POST['startTime']);
    $endTime = mysqli_real_escape_string($conn, $_POST['endTime']);
    $overallCost = mysqli_real_escape_string($conn, $_POST['overallCost']);
    $logisticalNeeds = mysqli_real_escape_string($conn, $_POST['logisticalNeeds']);
    $additionalDetails = mysqli_real_escape_string($conn, $_POST['additionalDetails']);

    // Determine the category based on the overall cost
    $category = ($overallCost >= 5000) ? "JHEPA" : "JPM";

    // Handle file uploads
    $tentativeContent = null;
    $tentativeType = null;
    if (!empty($_FILES['tentativeFile']['tmp_name'])) {
        $tentativeContent = file_get_contents($_FILES['tentativeFile']['tmp_name']);
        $tentativeType = $_FILES['tentativeFile']['type'];
        if (!$tentativeContent) {
            die("Failed to read tentative file");
        }
    }

    $costContent = null;
    $costType = null;
    if (!empty($_FILES['costFile']['tmp_name'])) {
        $costContent = file_get_contents($_FILES['costFile']['tmp_name']);
        $costType = $_FILES['costFile']['type'];
        if (!$costContent) {
            die("Failed to read cost file");
        }
    }

    // Set initial status
    $status = "Dihantar";

    $sql = "INSERT INTO paperwork (
        clubID,             -- 1  (i)
        program_name,       -- 2  (s)
        program_intro,      -- 3  (s)
        program_background, -- 4  (s)
        program_objective,  -- 5  (s)
        sdg,               -- 6  (s)
        sdg_subcategory,   -- 7  (s)
        program_themes,     -- 8  (s)
        program_org,       -- 9  (s)
        program_target,     -- 10 (s)
        start_date,        -- 11 (s) - Will be automatically converted to DATE by MySQL
        end_date,          -- 12 (s) - Will be automatically converted to DATE by MySQL
        start_time,        -- 13 (s) - Will be automatically converted to TIME by MySQL
        end_time,          -- 14 (s) - Will be automatically converted to TIME by MySQL
        overall_cost,      -- 15 (d) - Changed to double for decimal type
        logistical_needs,  -- 16 (s)
        additional_details, -- 17 (s)
        tentative_file,    -- 18 (b)
        tentative_file_type, -- 19 (s)
        cost_file,         -- 20 (b)
        cost_file_type,    -- 21 (s)
        status,            -- 22 (s)
        category           -- 23 (s)
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    
    // Updated bind_param type string:
    // i - integer (1)
    // s - strings (14)
    // d - decimal (1)
    // s - strings (2)
    // b - blobs (2)
    // s - strings (3)
    $stmt->bind_param(
        "isssssssssssssdsssbsbss",  // Exactly 23 characters for 23 parameters
        $clubID,
        $programName,
        $programIntro,
        $programBackground,
        $programObjective,
        $sdg,
        $sdgSubcategory,
        $programThemes,
        $programOrg,
        $programTarget,
        $startDate,
        $endDate,
        $startTime,
        $endTime,
        $overallCost,  // Changed to d for decimal type
        $logisticalNeeds,
        $additionalDetails,
        $tentativeContent,
        $tentativeType,
        $costContent,
        $costType,
        $status,
        $category
    );

    if ($stmt->execute()) {
        echo "<script>alert('Paperwork submitted successfully!'); window.location.href='mpp_homepage.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale= 1.0">
    <title>New Paperwork</title>
    <link rel="stylesheet" href="mpp_new_paperwork.css">
</head>
<body>
    <?php include('mpp_sidebar.php'); ?>
    <main>
        <header class="header">
            <div class="header-section">
                <div class="welcome-card">
                    <div class="welcome-text">
                        <h1>Create New Paperwork</h1>
                    </div>
                </div>
            </div>
        </header>
        <form action="mpp_new_paperwork.php" method="post" enctype="multipart/form-data">
            <div class="form-row">
                <div class="form-group">
                    <label for="programName">Program Name:</label>
                    <textarea id="programName" name="programName" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="programIntro">Introduction:</label>
                    <textarea id="programIntro" name="programIntro" rows="4" required></textarea>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="programBackground">Background:</label>
                    <textarea id="programBackground" name="programBackground" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="programObjective">Objective:</label>
                    <textarea id="programObjective" name="programObjective" rows="4" required></textarea>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="sdg">Sustainable Development Goals (SDG):</label>
                    <select id="sdg" name="sdg" required>
                        <option value="sdg1">SDG 1: Tiada Kemiskinan</option>
                        <option value="sdg2">SDG 2: Kelaparan Sifar</option>
                        <option value="sdg3">SDG 3: Kesihatan Baik dan Kesejahteraan</option>
                        <option value="sdg4">SDG 4: Pendidikan Berkualiti</option>
                        <option value="sdg5">SDG 5: Kesaksamaan Jantina</option>
                        <option value="sdg6">SDG 6: Air Bersih dan Sanitasi</option>
                        <option value="sdg7">SDG 7: Tenaga Berpatutan dan Bersih</option>
                        <option value="sdg8">SDG 8: Pekerjaan yang Layak dan Pertumbuhan Ekonomi</option>
                        <option value="sdg9">SDG 9: Industri, Inovasi dan Prasarana</option>
                        <option value="sdg10">SDG 10: Mengurangkan Ketidaksamaan</option>
                        <option value="sdg11">SDG 11: Bandar dan Masyarakat Mampan</option>
                        <option value="sdg12">SDG 12: Penggunaan dan Pengeluaran Bertanggungjawab</option>
                        <option value="sdg13">SDG 13: Tindakan terhadap Perubahan Iklim</option>
                        <option value="sdg14">SDG 14: Kehidupan Laut</option>
                        <option value="sdg15">SDG 15: Kehidupan di Darat</option>
                        <option value="sdg16">SDG 16: Keamanan, Keadilan dan Institusi yang Kuat</option>
                        <option value="sdg17">SDG 17: Kerjasama untuk Matlamat</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="programThemes">Themes:</label>
                    <input type="text" id="programThemes" name="programThemes" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="sdgSubcategory">SDG Sub-Category:</label>
                    <select id="sdgSubcategory" name="sdgSubcategory" required>
                        <!-- Populated dynamically via JavaScript -->
                    </select>
                </div>
                <div class="form-group">
                    <label for="programOrg">Organiser:</label>
                    <input type="text" id="programOrg" name="programOrg" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="programTarget">Target Group:</label>
                    <input type="text" id="programTarget" name="programTarget" required>
                </div>
                <div class="form-group">
                    <label for="startDate">Date:</label>
                    <div class="input-row">
                        <input type="date" id="startDate" name="startDate" required>
                        <span style="margin: 0 10px;">until</span>
                        <input type="date" id="endDate" name="endDate" required>
                    </div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="startTime">Time:</label>
                    <div class="input-row">
                        <input type="time" id="startTime" name="startTime" style="width: 178px;" required>
                        <span style="margin: 0 10px;">until</span>
                        <input type="time" id="endTime" name="endTime" style="width: 178px;" required>
                        <button type="button" id="uploadTentative" class="upload-button">Tentative (.pdf)</button>
                        <input type="file" id="tentativeFile" name="tentativeFile" accept=".pdf" style="display: none;" required>
                    </div>
                    <div id="tentativeFileDisplay" style="margin-top: 5px; color: #007BFF;">No file uploaded.</div>
                </div>
                <div class="form-group">
                    <label for="overallCost">Overall Cost:</label>
                    <div class="input-row">
                        <input type="number" id="overallCost" name="overallCost" step="0.01" placeholder="RM" style="width: 368px;" required>
                        <button type="button" id="uploadCost" class="upload-button">Financial Implications (.pdf)</button>
                        <input type="file" id="costFile" name="costFile" accept=".pdf" style="display: none;" required>
                    </div>
                    <div id="costFileDisplay" style="margin-top: 5px; color: #007BFF;">No file uploaded.</div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="logisticalNeeds">Logistical Needs:</label>
                    <textarea id="logisticalNeeds" name="logisticalNeeds" rows="4" required></textarea>
                </div>
                <div class="form-group">
                    <label for="additionalDetails">Additional Information:</label>
                    <textarea id="additionalDetails" name="additionalDetails" rows="4" required></textarea>
                </div>
            </div>
            
            <input type="submit" value="Submit" class="btn" id="submit">
        </form>

        <script>
            // Define subcategories for each SDG
            const subcategories = {
                sdg1: [
                    "1.1: Membasmi kemiskinan tegar",
                    "1.2: Mengurangkan kemiskinan sekurang-kurangnya 50%", 
                    "1.3: Melaksanakan sistem perlindungan sosial bersesuaian secara nasional",
                    "1.4: Hak sama rata untuk pemilikan, perkhidmatan asas, teknologi dan sumber ekonomi",
                    "1.5: Membina daya tahan terhadap bencana alam sekitar, ekonomi dan sosial",
                    "1.A: Penggemblengan sumber untuk menamatkan kemiskinan",
                    "1.B: Mewujudkan rangka kerja dasar pembasmian kemiskinan di semua peringkat"
                ],
                sdg2: [
                    "2.1: Akses sejagat kepada makanan yang selamat dan berkhasiat", 
                    "2.2: Menamatkan semua bentuk malnutrisi", 
                    "2.3: Menggandakan produktiviti dan pendapatan pengeluar makanan berskala kecil",
                    "2.4: Pengeluaran makanan yang mampan dan amalan pertanian yang berdaya tahan",
                    "2.5: Mengekalkan kepelbagaian genetik dalam pengeluaran makanan",
                    "2.A: Melabur dalam infrastruktur luar bandar, penyelidikan pertanian, teknologi dan bank gen",
                    "2.B.: Menghalang sekatan perdagangan pertanian, gangguan pasaran dan subsidi eksport",
                    "2.C. Memastikan pasaran komoditi makanan yang stabil dan akses terkini kepada maklumat"
                ],
                sdg3: [
                    "3.1: Mengurangkan kematian bersalin",
                    "3.2: Menamatkan semua kematian boleh dicegah di bawah umur lima tahun",
                    "3.3: Memerangi penyakit berjangkit",
                    "3.4: Mengurangkan kematian akibat penyakit tidak berjangkit dan menggalakkan kesihatan mental",
                    "3.5: Mencegah dan merawat penyalahgunaan bahan",
                    "3.6: Mengurangkan kecederaan dan kematian jalan raya",
                    "3.7: Akses sejagat kepada penjagaan seksual dan reproduktif, perancangan keluarga dan pendidikan",
                    "3.8: Mencapai perlindungan kesihatan sejagat",
                    "3.9: Mengurangkan penyakit dan kematian akibat bahan kimia berbahaya dan pencemaran",
                    "3.A: Melaksanakan konvensyen rangka kerja WHO mengenai kawalan tembakau",
                    "3.B: Menyokong penyelidikan, pembangunan dan akses universal kepada vaksin dan ubat mampu milik",
                    "3.C: Meningkatkan pembiayaan kesihatan dan menyokong tenaga kerja kesihatan di negara membangun",
                    "3.D: Memperbaik sistem amaran awal terhadap risiko kesihatan global"
                ],
                sdg4: [
                    "4.1: Pendidikan rendah dan menengah percuma",
                    "4.2: Akses sama rata kepada pendidikan prasekolah yang berkualiti",
                    "4.3: Akses sama rata kepada pendidikan teknikal, vokasional dan tinggi yang berpatutan",
                    "4.4: Meningkatkan bilangan orang yang mempunyai kemahiran yang relevan demi kejayaan kewangan",
                    "4.5: Menghapuskan semua diskriminasi dalam pendidikan",
                    "4.6: Literasi dan numerasi sejagat",
                    "4.7: Pendidikan demi pembangunan mampan dan kewarganegaraan global",
                    "4.A: Membina dan menaik taraf sekolah inklusif dan selamat",
                    "4.B: Memperluaskan biasiswa pendidikan tinggi untuk negara membangun",
                    "4.C: Meningkatkan bekalan guru yang berkelayakan di negara membangun"
                ],
                sdg5: [
                    "5.1: Menamatkan diskriminasi terhadap wanita dan kanak-kanak perempuan",
                    "5.2: Menamatkan semua keganasan dan eksploitasi terhadap wanita dan kanak-kanak perempuan",
                    "5.3: Menghapuskan perkahwinan paksa dan mutilasi alat kelamin",
                    "5.4: Menghargai penjagaan tanpa gaji dan menggalakkan tanggungjawab domestik bersama",
                    "5.5: Memastikan penyertaan penuh dalam kepimpinan dan membuat keputusan",
                    "5.6: Akses sejagat kepada hak reproduktif dan kesihatan",
                    "5.A: Hak sama rata kepada sumber ekonomi, pemilikan harta dan perkhidmatan kewangan",
                    "5.B: Menggalakkan pemerkasaan wanita melalui teknologi",
                    "5.C: Mengguna pakai dan mengukuhkan dasar dan perundangan yang boleh dikuatkuasakan demi kesaksamaan jantina"
                ],
                sdg6: [
                    "6.1: Air minuman yang selamat dan berpatutan",
                    "6.2: Menamatkan pembuangan air terbuka dan menyediakan akses kepada sanitasi dan kebersihan",
                    "6.3: Meningkatkan kualiti air, rawatan air sisa dan penggunaan semula yang selamat",
                    "6.4: Meningkatkan kecekapan penggunaan air dan menjamin bekalan air tawar",
                    "6.5: Melaksanakan IWRM",
                    "6.6: Melindungi dan memulihkan ekosistem berkaitan air",
                    "6.A: Meluaskan sokongan air dan sanitasi di negara membangun",
                    "6.B: Menyokong penglibatan tempatan dalam pengurusan air dan sanitasi"
                ],
                sdg7: [
                    "7.1: Akses sejagat terhadap tenaga moden",
                    "7.2: Meningkatkan peratusan tenaga boleh diperbaharui global",
                    "7.3: Gandakan peningkatan kecekapan tenaga",
                    "7.A: Menggalakkan akses kepada penyelidikan, teknologi dan pelaburan dalam tenaga bersih",
                    "7.B: Memperluas dan menaik taraf perkhidmatan tenaga di negara membangun"
                ],
                sdg8: [
                    "8.1: Pertumbuhan ekonomi mampan",
                    "8.2: Mempelbagaikan, berinovasi dan naik taraf untuk produktiviti ekonomi",
                    "8.3: Menggalakkan dasar utk menyokong penciptaan pekerjaan dan perusahaan yang sedang berkembang",
                    "8.4: Meningkatkan kecekapan sumber dalam penggunaan dan pengeluaran",
                    "8.5: Kadar pekerjaan penuh dan kerja yang layak dengan gaji yang sama",
                    "8.6: Menggalakkan pekerjaan, pendidikan dan latihan belia",
                    "8.7: Menamatkan perhambaan moden, pemerdagangan, dan buruh kanak-kanak",
                    "8.8: Melindungi hak buruh dan menggalakkan persekitaran kerja yang selamat",
                    "8.9: Menggalakkan pelancongan yang bermanfaat dan mampan",
                    "8.10: Akses sejagat kepada perkhidmatan perbankan, insurans dan kewangan",
                    "8.A: Meningkatkan bantuan sokongan perdagangan",
                    "8.B: Membangunkan strategi pekerjaan belia global"
                ],
                sdg9: [
                    "9.1: Membangunkan infrastruktur yang mampan, berdaya tahan dan inklusif",
                    "9.2: Menggalakkan perindustrian yang inklusif dan mampan",
                    "9.3: Meningkatkan akses kepada perkhidmatan kewangan dan pasaran",
                    "9.4: Menaik taraf semua industri dan infrastruktur untuk kemampanan",
                    "9.5: Meningkatkan penyelidikan dan menaik taraf teknologi perindustrian",
                    "9.A: Memudahkan pembangunan infrastruktur yang mampan untuk negara membangun",
                    "9.B: Menyokong pembangunan teknologi domestik dan kepelbagaian industri",
                    "9.C: Akses sejagat kepada teknologi maklumat dan komunikasi"
                ],
                sdg10: [
                    "10.1: Mengurangkan ketidaksamaan pendapatan",
                    "10.2: Menggalakkan keterangkuman sosial, ekonomi dan politik sejagat",
                    "10.3: Memastikan peluang sama rata dan menamatkan diskriminasi",
                    "10.4: Mengguna pakai dasar fiskal dan sosial yang menggalakkan kesaksamaan",
                    "10.5: Peraturan yang lebih baik bagi pasaran dan institusi kewangan global",
                    "10.6: Perwakilan yang dipertingkatkan untuk negara membangun dalam institusi kewangan",
                    "10.7: Dasar migrasi yang bertanggungjawab dan diurus dengan baik",
                    "10.a: Layanan istimewa dan berbeza bagi negara membangun",
                    "10.b: Menggalakkan bantuan pembangunan dan pelaburan di negara kurang maju",
                    "10.c: Mengurangkan kos urus niaga bagi kiriman wang migran"
                ],
                sdg11: [
                    "11.1: Perumahan yang selamat dan mampu milik",
                    "11.2: Sistem pengangkutan yang berpatutan dan mampan",
                    "11.3: Perbandaran inklusif dan mampan",
                    "11.4: Lindungi warisan budaya dan semula jadi dunia",
                    "11.5: Mengurangkan kesan buruk bencana alam",
                    "11.6: Mengurangkan kesan alam sekitar bandar",
                    "11.7: Sediakan akses kepada ruang hijau dan awam yang selamat dan inklusif",
                    "11.a: Perancangan pembangunan negara dan wilayah yang kukuh",
                    "11.b: Melaksanakan dasar demi inklusiviti, kecekapan sumber dan pengurangan risiko bencana",
                    "11.c: Menyokong negara kurang maju dalam pembinaan mampan dan berdaya tahan"
                ],
                sdg12: [
                    "12.1: Melaksanakan rangka kerja penggunaan dan pengeluaran mampan 10 tahun",
                    "12.2: Pengurusan mampan dan penggunaan sumber asli",
                    "12.3: Mengurangkan separuh sisa makanan per kapita global",
                    "12.4: Pengurusan bertanggungjawab terhadap bahan kimia dan sisa",
                    "12.5: Mengurangkan penjanaan sisa dengan ketara",
                    "12.6: Menggalakkan syarikat untuk menerima pakai amalan mampan dan pelaporan kemampanan",
                    "12.7: Menggalakkan amalan perolehan awam yang mampan",
                    "12.8: Menggalakkan pemahaman sejagat tentang gaya hidup mampan",
                    "12.a: Menyokong kapasiti saintifik dan teknologi negara membangun terhadap penggunaan dan pengeluaran yang mampan",
                    "12.b: Membangun dan melaksanakan alat untuk memantau pelancongan mampan",
                    "12.c: Menghapuskan herotan pasaran yang menggalakkan penggunaan membazir"
                ],
                sdg13: [
                    "13.1: Memperkukuh daya tahan dan kapasiti penyesuaian terhadap bencana berkaitan iklim",
                    "13.2: Mengintegrasikan langkah-langkah perubahan iklim ke dalam dasar dan perancangan",
                    "13.3: Bina pengetahuan dan kapasiti untuk memenuhi perubahan iklim",
                    "13.a: Melaksanakan Konvensyen Rangka Kerja PBB mengenai Perubahan Iklim",
                    "13.b: Menggalakkan mekanisme untuk meningkatkan kapasiti untuk perancangan dan pengurusan"
                ],
                sdg14: [
                    "14.1: Mengurangkan pencemaran marin",
                    "14.2: Melindungi dan memulihkan ekosistem",
                    "14.3: Mengurangkan pengasidan lautan",
                    "14.4: Perikanan mampan",
                    "14.5: Memulihara kawasan pantai dan marin",
                    "14.6: Menamatkan subsidi yang menyumbang kepada penangkapan ikan berlebihan",
                    "14.7: Meningkatkan faedah ekonomi daripada penggunaan sumber marin secara mampan",
                    "14.a: Meningkatkan pengetahuan saintifik, penyelidikan dan teknologi untuk kesihatan lautan",
                    "14.b: Menyokong nelayan skala kecil",
                    "14.c: Melaksana dan menguatkuasakan undang-undang laut antarabangsa"
                ],
                sdg15: [
                    "15.1: Memulihara dan memulihkan ekosistem daratan dan air tawar",
                    "15.2: Menamatkan penebangan hutan dan memulihkan hutan yang rosak",
                    "15.3: Menamatkan penggurunan dan memulihkan tanah yang rosak",
                    "15.4: Memastikan pemuliharaan ekosistem gunung",
                    "15.5: Melindungi biodiversiti dan habitat semula jadi",
                    "15.5.A: Kurangkan urbanisasi",
                    "15.6: Lindungi akses kepada sumber genetik dan perkongsian manfaat yang adil",
                    "15.7: Menghapuskan pemburuan haram dan pemerdagangan spesies yang dilindungi",
                    "15.8: Mencegah spesies asing invasif di darat dan dalam ekosistem air",
                    "15.9: Mengintegrasikan ekosistem dan biodiversiti dalam perancangan pentadbiran",
                    "15.a: Meningkatkan sumber kewangan untuk memulihara dan menggunakan ekosistem dan biodiversiti secara mampan",
                    "15.b: Membiayai dan memberi insentif kepada pengurusan hutan lestari",
                    "15.c: Membanteras pemburuan haram dan pemerdagangan global"
                ],
                sdg16: [
                    "16.1: Mengurangkan keganasan di mana-mana sahaja",
                    "16.2: Melindungi kanak-kanak daripada penderaan, eksploitasi, pemerdagangan dan keganasan",
                    "16.3: Menggalakkan kedaulatan undang-undang dan memastikan akses yang sama kepada keadilan",
                    "16.4: Membanteras jenayah terancang dan aliran kewangan dan senjata haram",
                    "16.5: Mengurangkan korupsi dan rasuah dengan ketara",
                    "16.6: Membangunkan institusi yang berkesan, bertanggungjawab dan telus",
                    "16.7: Memastikan pembuatan keputusan yang responsif, inklusif dan berperwakilan",
                    "16.8: Memperkukuh penyertaan dalam tadbir urus global",
                    "16.9: Menyediakan identiti undang-undang sejagat",
                    "16.10: Memastikan akses awam kepada maklumat dan melindungi kebebasan asas",
                    "16.a: Memperkukuh institusi negara untuk mencegah keganasan dan memerangi jenayah dan terorisme",
                    "16.b: Mempromosikan dan menguatkuasakan undang-undang dan dasar tanpa diskriminasi"
                ],
                sdg17: [
                    "17.1: Menggerakkan sumber untuk menambah baik kutipan hasil dalam negeri",
                    "17.2: Melaksanakan semua komitmen bantuan pembangunan",
                    "17.3: Menggerakkan sumber kewangan untuk negara membangun",
                    "17.4: Membantu negara membangun dalam mencapai kemampanan hutang",
                    "17.5: Melabur di negara kurang maju",
                    "17.6: Perkongsian pengetahuan dan kerjasama demi akses kepada sains, teknologi dan inovasi",
                    "17.7: Mempromosikan teknologi mampan kepada negara membangun",
                    "17.8: Memperkukuh kapasiti sains, teknologi dan inovasi untuk negara kurang membangun",
                    "17.9: Peningkatan kapasiti SDG di negara membangun",
                    "17.10: Menggalakkan sistem perdagangan sejagat di bawah WTO",
                    "17.11: Meningkatkan eksport negara membangun",
                    "17.12: Menghapuskan halangan perdagangan bagi negara kurang membangun",
                    "17.13: Meningkatkan kestabilan makroekonomi global",
                    "17.14: Meningkatkan keselarasan dasar untuk pembangunan mampan",
                    "17.15: Menghormati kepimpinan negara untuk melaksanakan dasar bagi matlamat pembangunan mampan",
                    "17.16: Meningkatkan kerjasama global demi pembangunan mampan",
                    "17.17: Menggalakkan kerjasama berkesan",
                    "17.18: Meningkatkan ketersediaan data boleh dipercayai",
                    "17.19: Membangunkan lagi ukuran kemajuan"
                ]
            };

            // Function to update subcategory dropdown based on selected SDG
            document.getElementById('sdg').addEventListener('change', function() {
                const selectedSDG = this.value;
                const subcategoryDropdown = document.getElementById('sdgSubcategory');
                
                // Clear the existing options
                subcategoryDropdown.innerHTML = "";

                // Populate the subcategory dropdown with relevant options
                if (subcategories[selectedSDG]) {
                    subcategories[selectedSDG].forEach(sub => {
                        const option = document.createElement('option');
                        option.value = sub;
                        option.textContent = sub;
                        subcategoryDropdown.appendChild(option);
                    });
                }
            });

            // Initialize the subcategory dropdown based on default SDG selection
            document.getElementById('sdg').dispatchEvent(new Event('change'));

            // Handle Tentatif Program file upload
            document.getElementById('uploadTentative').addEventListener('click', function () {
                document.getElementById('tentativeFile').click();
            });

            document.getElementById('tentativeFile').addEventListener('change', function () {
                const fileName = this.files.length > 0 ? this.files[0].name : "No file uploaded.";
                document.getElementById('tentativeFileDisplay').textContent = fileName;
            });

            // Handle Implikasi Kewangan file upload
            document.getElementById('uploadCost').addEventListener('click', function () {
                document.getElementById('costFile').click();
            });

            document.getElementById('costFile').addEventListener('change', function () {
                const fileName = this.files.length > 0 ? this.files[0].name : "No file uploaded.";
                document.getElementById('costFileDisplay').textContent = fileName;
            });
        </script>
    </main>

        <style>
        /* Base styles */
        html, body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f0f2f5;
        }

        /* Main content area */
        main {
            margin-left: 200px;
            padding: 20px 40px;
            background-color: #f0f2f5;
        }

        /* Header section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 20px;
            color: white;
            display: flex;
            justify-content: center; /* Center the content */
            align-items: center;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
            margin-bottom: 30px;
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            text-align: center; /* Center the text */
        }

        /* Form container */
        form {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Form row layout */
        .form-row {
            display: flex;
            gap: 40px;
            margin-bottom: 40px;
            width: 100%;
        }

        .form-group {
            flex: 1;
            width: 50%;
            min-width: 0;
        }

        /* Form elements */
        label {
            display: block;
            font-weight: 600;
            color: #1a365d;
            margin-bottom: 12px;
            font-size: 14px;
        }

        input, textarea, select {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s;
            background-color: #f8fafc; /* Light background for form fields */
            box-sizing: border-box;
        }

        input:hover, textarea:hover, select:hover {
            border-color: #90cdf4;
            background-color: #fff;
        }

        input:focus, textarea:focus, select:focus {
            outline: none;
            border-color: #0061f2;
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.15);
            background-color: #fff;
        }

        textarea {
            resize: vertical;
            min-height: 100px;
        }

        /* Time and date container styling */
        .input-row {
            display: flex;
            align-items: center;
            gap: 15px;
            width: 100%;
        }

        /* Time inputs and date inputs */
        input[type="time"],
        input[type="date"] {
            flex: 1;
            min-width: 0;
            padding: 10px;
            background-color: #f8fafc;
        }

        /* Cost input with upload button */
        input[type="number"] {
            width: calc(60% - 15px);
            background-color: #f8fafc;
        }

        /* Upload buttons */
        .upload-button {
            background-color: #0061f2;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s;
            white-space: nowrap;
            width: 40%;
            box-shadow: 0 2px 4px rgba(0, 97, 242, 0.1);
        }

        .upload-button:hover {
            background-color: #0056b3;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0, 97, 242, 0.2);
        }

        /* File display text */
        #tentativeFileDisplay,
        #costFileDisplay {
            margin-top: 8px;
            font-size: 13px;
            color: #0061f2;
        }

        /* Submit button */
        #submit {
            background-color: #10b981;
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 30px;
            width: auto;
            display: block;
            margin-left: auto;
            box-shadow: 0 2px 4px rgba(16, 185, 129, 0.1);
        }

        #submit:hover {
            background-color: #059669;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(16, 185, 129, 0.2);
        }

        /* Responsive design */
        @media (max-width: 1024px) {
            main {
                margin-left: 0;
                padding: 20px;
            }

            form {
                padding: 20px;
            }

            .form-row {
                flex-direction: column;
                gap: 30px;
            }

            .form-group {
                width: 100%;
            }

            .input-row {
                flex-wrap: wrap;
            }

            .upload-button {
                width: 100%;
                margin-top: 10px;
            }

            input[type="number"] {
                width: 100%;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-group {
            animation: fadeIn 0.5s ease-out forwards;
        }

        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        ::-webkit-scrollbar-thumb {
            background: #0061f2;
            border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: #0056b3;
        }
    </style>
</body>
</html>
