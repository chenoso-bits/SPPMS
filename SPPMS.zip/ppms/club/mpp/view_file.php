<?php
session_start();
include('../../connection.php');

if (!isset($_SESSION['clubID']) || !isset($_GET['id']) || !isset($_GET['type'])) {
    die("Unauthorized access or missing parameters");
}

$paperworkID = $_GET['id'];
$fileType = $_GET['type']; // 'tentative' or 'cost'
$clubID = $_SESSION['clubID'];

// Verify user has access to this paperwork
$sql = "SELECT " . ($fileType === 'tentative' ? 'tentative_file, tentative_file_type' : 'cost_file, cost_file_type') . 
       " FROM paperwork WHERE id = ? AND clubID = ?";
       
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $paperworkID, $clubID);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $fileContent = $fileType === 'tentative' ? $row['tentative_file'] : $row['cost_file'];
    $mimeType = $fileType === 'tentative' ? $row['tentative_file_type'] : $row['cost_file_type'];
    
    // Set proper headers
    header('Content-Type: ' . $mimeType);
    header('Content-Disposition: inline; filename="' . $fileType . '_file.pdf"');
    
    // Output the file content
    echo $fileContent;
    exit;
} else {
    die("File not found or unauthorized access");
}

$stmt->close();
$conn->close();
?>