<?php
session_start();
if (isset($_SESSION['sMatrics'])) {
    $_SESSION = array();
    session_destroy();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "ppms");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Keep all existing PHP functions from the original code
function getDashboardStats($conn) {
    $stats = array();
    
    // Total clubs
    $clubQuery = "SELECT COUNT(DISTINCT clubID) as total FROM club";
    $result = $conn->query($clubQuery);
    $stats['totalClubs'] = $result->fetch_assoc()['total'];
    
    // Total paperwork
    $paperworkQuery = "SELECT COUNT(id) as total FROM paperwork";
    $result = $conn->query($paperworkQuery);
    $stats['totalPaperwork'] = $result->fetch_assoc()['total'];
    
    // Approved paperwork
    $approvedQuery = "SELECT COUNT(id) as total FROM paperwork WHERE status = 'Diluluskan'";
    $result = $conn->query($approvedQuery);
    $stats['approvedPaperwork'] = $result->fetch_assoc()['total'];
    
    // Pending paperwork
    $pendingQuery = "SELECT COUNT(id) as total FROM paperwork WHERE status = 'Disemak'";
    $result = $conn->query($pendingQuery);
    $stats['pendingPaperwork'] = $result->fetch_assoc()['total'];
    
    return $stats;
}

function getDimensionStats($conn) {
    $dimensions = array();
    $query = "SELECT c.clubDimension, COUNT(p.id) as count 
              FROM paperwork p 
              JOIN club c ON p.clubID = c.clubID 
              GROUP BY c.clubDimension";
    $result = $conn->query($query);
    
    while($row = $result->fetch_assoc()) {
        $dimensions[] = array(
            'dimension' => $row['clubDimension'],
            'count' => $row['count']
        );
    }
    return $dimensions;
}

function getMonthlySubmissions($conn) {
    $submissions = array();
    $query = "SELECT MONTH(created_at) as month, COUNT(id) as count 
              FROM paperwork 
              WHERE YEAR(created_at) = YEAR(CURRENT_DATE())
              GROUP BY MONTH(created_at)
              ORDER BY month";
    $result = $conn->query($query);
    
    while($row = $result->fetch_assoc()) {
        $submissions[] = array(
            'month' => date('M', mktime(0, 0, 0, $row['month'], 1)),
            'count' => $row['count']
        );
    }
    return $submissions;
}

function getCalendarEvents($conn) {
    $events = array();
    $query = "SELECT program_name as title, 
                     start_date as start, 
                     end_date as end,
                     program_org as location
              FROM paperwork 
              WHERE status = 'Diluluskan'";
    $result = $conn->query($query);
    
    while($row = $result->fetch_assoc()) {
        $events[] = array(
            'title' => $row['title'],
            'start' => $row['start'],
            'end' => $row['end'],
            'location' => $row['location']
        );
    }
    return $events;
}

function getAdditionalStats($conn) {
    $additionalStats = array();
    
    // Most active clubs
    $activeClubsQuery = "SELECT c.clubName, COUNT(p.id) as submission_count 
                        FROM club c 
                        JOIN paperwork p ON c.clubID = p.clubID 
                        GROUP BY c.clubID 
                        ORDER BY submission_count DESC 
                        LIMIT 5";
    $result = $conn->query($activeClubsQuery);
    while($row = $result->fetch_assoc()) {
        $additionalStats['activeClubs'][] = $row;
    }
    
    // Average cost of approved programs
    $costQuery = "SELECT AVG(overall_cost) as avg_cost 
                 FROM paperwork 
                 WHERE status = 'Diluluskan'";
    $result = $conn->query($costQuery);
    $additionalStats['avgCost'] = $result->fetch_assoc()['avg_cost'];
    
    return $additionalStats;
}

function getUpcomingEvents($conn, $limit = 5) {
    $query = "SELECT p.program_name, p.start_date, p.program_org, c.clubName 
              FROM paperwork p
              JOIN club c ON p.clubID = c.clubID
              WHERE p.status = 'Diluluskan' 
              AND p.start_date >= CURDATE()
              ORDER BY p.start_date ASC 
              LIMIT ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $events = array();
    while($row = $result->fetch_assoc()) {
        $events[] = $row;
    }
    return $events;
}

function getRecentAchievements($conn, $limit = 5) {
    $query = "SELECT p.program_name, p.program_target, c.clubName, p.sdg
              FROM paperwork p
              JOIN club c ON p.clubID = c.clubID
              WHERE p.status = 'Diluluskan'
              AND p.end_date < CURDATE()
              ORDER BY p.end_date DESC
              LIMIT ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getSDGStats($conn) {
    $query = "SELECT sdg, COUNT(*) as count
              FROM paperwork
              WHERE status = 'Diluluskan'
              GROUP BY sdg
              ORDER BY count DESC";
    
    $result = $conn->query($query);
    $sdgStats = array();
    while($row = $result->fetch_assoc()) {
        $sdgStats[] = $row;
    }
    return $sdgStats;
}

function getActiveClubStats($conn) {
    $query = "SELECT c.clubName, 
                     COUNT(p.id) as program_count,
                     c.clubDimension
              FROM club c
              LEFT JOIN paperwork p ON c.clubID = p.clubID
              WHERE p.status = 'Diluluskan'
              GROUP BY c.clubID
              ORDER BY program_count DESC
              LIMIT 5";
    
    $result = $conn->query($query);
    return $result->fetch_all(MYSQLI_ASSOC);
}

function getCategoryStats($conn) {
    $query = "SELECT category, COUNT(*) as count
              FROM paperwork
              WHERE status = 'Diluluskan'
              GROUP BY category
              ORDER BY count DESC";
    
    $result = $conn->query($query);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Fetch all data
$stats = getDashboardStats($conn);
$dimensions = getDimensionStats($conn);
$monthlySubmissions = getMonthlySubmissions($conn);
$calendarEvents = getCalendarEvents($conn);
$additionalStats = getAdditionalStats($conn);
$upcomingEvents = getUpcomingEvents($conn);
$recentAchievements = getRecentAchievements($conn);
$sdgStats = getSDGStats($conn);
$activeClubs = getActiveClubStats($conn);
$categoryStats = getCategoryStats($conn);

// Convert to JSON for JavaScript use
$statsJson = json_encode($stats);
$dimensionsJson = json_encode($dimensions);
$submissionsJson = json_encode($monthlySubmissions);
$eventsJson = json_encode($calendarEvents);
$sdgStatsJson = json_encode($sdgStats);
$categoryStatsJson = json_encode($categoryStats);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPPMS - Student Program & Paperwork Management System</title>
    
    <!-- CSS Dependencies -->
    <link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css' rel='stylesheet' />
    <link href='https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css' rel='stylesheet' />
    
    <!-- JavaScript Dependencies -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js'></script>

    <style>
        :root {
            --primary-gradient: linear-gradient(to right, #4F46E5, #3B82F6);
            --secondary-gradient: linear-gradient(to bottom right, #EEF2FF, #E0E7FF);
        }

        body {
            margin: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: var(--secondary-gradient);
            min-height: 100vh;
            background: url('image/bg.png') ;
        }

        .gradient-text {
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }

        .header {
            background: white;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .stat-card {
            background: white;
            border-radius: 1rem;
            padding: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .chart-container {
            background: white;
            border-radius: 1rem;
            padding: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
        }

        .button {
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 500;
            transition: all 0.2s ease-in-out;
        }

        .button-primary {
            background: var(--primary-gradient);
            color: white;
        }

        .button-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 1rem;
            background: #F3F4F6;
            border-radius: 0.5rem;
            margin-bottom: 0.75rem;
        }

        .activity-icon {
            background: #EEF2FF;
            padding: 0.75rem;
            border-radius: 50%;
            margin-right: 1rem;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background: white;
            min-width: 160px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border-radius: 0.5rem;
            z-index: 1000;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-item {
            padding: 0.75rem 1rem;
            color: #374151;
            text-decoration: none;
            display: block;
        }

        .dropdown-item:hover {
            background: #F3F4F6;
        }

        /* Calendar customization */
        .fc-header-toolbar {
            padding: 1rem;
            background: white;
            border-radius: 0.5rem;
            margin-bottom: 1rem !important;
        }

        .fc-day-header {
            background: #F3F4F6;
            padding: 0.75rem !important;
        }

        .fc-event {
            border: none !important;
            background: var(--primary-gradient) !important;
            padding: 0.25rem;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="max-w-7xl mx-auto px-4 py-6">
            <div class="flex justify-between items-center">
                <h1 class="text-3xl font-bold gradient-text">Student Program Paperwork Management System</h1>
                <div class="flex gap-4">
                    <div class="dropdown">
                        <button class="button button-primary">Login</button>
                        <div class="dropdown-content">
                            <a href="club/club_login.php" class="dropdown-item">as Club/Associations</a>
                            <a href="staff/staff_login.php" class="dropdown-item">as Staff</a>
                        </div>
                    </div>
                    <div class="dropdown">
                        <button class="button button-primary">Download</button>
                        <div class="dropdown-content">
                            <a href="jpm_format.docx" class="dropdown-item">JPM</a>
                            <a href="jhepa_format.docx" class="dropdown-item">JHEPA</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 py-8">
        <!-- Statistics Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="stat-card">
                <h3 class="text-gray-500 text-sm mb-2">Total Clubs</h3>
                <p class="text-2xl font-bold"><?php echo $stats['totalClubs']; ?></p>
                <div class="mt-2 text-blue-600">
                    <svg class="w-6 h-6 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                </div>
            </div>

            <div class="stat-card">
                <h3 class="text-gray-500 text-sm mb-2">Total Paperwork</h3>
                <p class="text-2xl font-bold"><?php echo $stats['totalPaperwork']; ?></p>
                <div class="mt-2 text-indigo-600">
                    <svg class="w-6 h-6 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
            </div>

            <div class="stat-card">
                <h3 class="text-gray-500 text-sm mb-2">Approved</h3>
                <p class="text-2xl font-bold text-green-600"><?php echo $stats['approvedPaperwork']; ?></p>
                <div class="mt-2 text-green-600">
                    <svg class="w-6 h-6 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>

            <div class="stat-card">
                <h3 class="text-gray-500 text-sm mb-2">Pending</h3>
                <p class="text-2xl font-bold text-yellow-600"><?php echo $stats['pendingPaperwork']; ?></p>
                <div class="mt-2 text-yellow-600">
                    <svg class="w-6 h-6 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>
        </div>

        <!-- Charts Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div class="chart-container">
                <h3 class="text-lg font-semibold mb-6">Monthly Submissions</h3>
                <canvas id="submissionsChart"></canvas>
            </div>

            <div class="chart-container">
                <h3 class="text-lg font-semibold mb-6">Club Dimensions</h3>
                <canvas id="dimensionsChart"></canvas>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="chart-container">
            <h3 class="text-lg font-semibold mb-6">Recent Activities</h3>
            <div class="space-y-4">
                <?php foreach($upcomingEvents as $event): ?>
                <div class="activity-item">
                    <div class="activity-icon">
                        <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                    </div>
                    <div>
                        <p class="font-medium"><?php echo htmlspecialchars($event['program_name']); ?></p>
                        <p class="text-sm text-gray-500">
                            <?php echo date('d M Y', strtotime($event['start_date'])); ?> by 
                            <?php echo htmlspecialchars($event['clubName']); ?>
                        </p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Calendar Section -->
        <div class="chart-container mt-8">
            <h3 class="text-lg font-semibold mb-6">Event Calendar</h3>
            <div id="calendar"></div>
        </div>

        <!-- Additional Stats Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
            <div class="chart-container">
                <h3 class="text-lg font-semibold mb-6">SDG Distribution</h3>
                <canvas id="sdgChart"></canvas>
            </div>

            <div class="chart-container">
                <h3 class="text-lg font-semibold mb-6">Program Categories</h3>
                <canvas id="categoryChart"></canvas>
            </div>
        </div>

        <!-- Active Clubs Table -->
        <div class="chart-container mt-8">
            <h3 class="text-lg font-semibold mb-6">Most Active Clubs</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Club Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Programs</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dimension</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach($activeClubs as $club): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($club['clubName']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo $club['program_count']; ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo htmlspecialchars($club['clubDimension']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                    Active
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <footer class="bg-white mt-8 border-t border-gray-200">
        <div class="max-w-7xl mx-auto py-6 px-4">
            <p class="text-center text-gray-500 text-sm">© <?php echo date('Y'); ?> SPPMS. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Initialize all charts when the document is ready
        document.addEventListener('DOMContentLoaded', function() {
            // Submissions Chart
            const submissionsData = <?php echo $submissionsJson; ?>;
            new Chart(document.getElementById('submissionsChart').getContext('2d'), {
                type: 'line',
                data: {
                    labels: submissionsData.map(item => item.month),
                    datasets: [{
                        label: 'Submissions',
                        data: submissionsData.map(item => item.count),
                        fill: true,
                        backgroundColor: 'rgba(79, 70, 229, 0.1)',
                        borderColor: 'rgb(79, 70, 229)',
                        tension: 0.4,
                        borderWidth: 2,
                        pointBackgroundColor: 'white',
                        pointBorderColor: 'rgb(79, 70, 229)',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                            backgroundColor: 'white',
                            titleColor: 'black',
                            bodyColor: 'black',
                            borderColor: 'rgb(229, 231, 235)',
                            borderWidth: 1,
                            padding: 12,
                            displayColors: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                borderDash: [2, 2]
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });

            // Dimensions Chart
            const dimensionsData = <?php echo $dimensionsJson; ?>;
            new Chart(document.getElementById('dimensionsChart').getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: dimensionsData.map(item => item.dimension),
                    datasets: [{
                        data: dimensionsData.map(item => item.count),
                        backgroundColor: [
                            'rgb(79, 70, 229)',
                            'rgb(59, 130, 246)',
                            'rgb(16, 185, 129)',
                            'rgb(245, 158, 11)'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    },
                    cutout: '60%'
                }
            });

            // SDG Chart
            const sdgData = <?php echo $sdgStatsJson; ?>;
            new Chart(document.getElementById('sdgChart').getContext('2d'), {
                type: 'bar',
                data: {
                    labels: sdgData.map(item => item.sdg),
                    datasets: [{
                        label: 'Programs',
                        data: sdgData.map(item => item.count),
                        backgroundColor: 'rgb(79, 70, 229)',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                borderDash: [2, 2]
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });

            // Category Chart
            const categoryData = <?php echo $categoryStatsJson; ?>;
            new Chart(document.getElementById('categoryChart').getContext('2d'), {
                type: 'pie',
                data: {
                    labels: categoryData.map(item => item.category),
                    datasets: [{
                        data: categoryData.map(item => item.count),
                        backgroundColor: [
                            'rgb(79, 70, 229)',
                            'rgb(59, 130, 246)',
                            'rgb(16, 185, 129)',
                            'rgb(245, 158, 11)',
                            'rgb(236, 72, 153)'
                        ],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            });

            // Initialize Calendar
            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                events: <?php echo $eventsJson; ?>,
                themeSystem: 'standard',
                height: 'auto',
                eventLimit: true,
                eventRender: function(event, element) {
                    element.find('.fc-title').append('<br/>' + event.location);
                },
                eventClick: function(calEvent, jsEvent, view) {
                    alert('Event: ' + calEvent.title);
                },
                dayClick: function(date, jsEvent, view) {
                    console.log('Clicked on: ' + date.format());
                }
            });
        });

        // Add smooth scrolling to all navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation to stat cards on scroll
        const observerOptions = {
            threshold: 0.1
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-fade-in');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.stat-card').forEach((card) => {
            observer.observe(card);
        });
    </script>
</body>
</html>