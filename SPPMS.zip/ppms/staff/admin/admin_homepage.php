<?php
session_start();
require_once '../../connection.php';

// Check admin session
if (!isset($_SESSION['staffRole']) || $_SESSION['staffRole'] !== 'Admin') {
    header('Location: ../staff_login.php');
    exit();
}

// Get paperwork statistics with prepared statements
function getPaperworkStats($conn) {
    $query = "SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'Dihantar' THEN 1 END) as pending_review,
        COUNT(CASE WHEN status = 'Disemak' THEN 1 END) as in_review,
        COUNT(CASE WHEN status = 'Diluluskan' THEN 1 END) as approved,
        COUNT(CASE WHEN status = 'Ditolak' THEN 1 END) as rejected
    FROM paperwork";
    
    $result = $conn->query($query);
    return $result->fetch_assoc();
}

// Get recent submissions
function getRecentSubmissions($conn, $limit = 5) {
    $query = "SELECT p.*, c.clubName 
              FROM paperwork p
              JOIN club c ON p.clubID = c.clubID
              ORDER BY p.created_at DESC 
              LIMIT ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Get upcoming deadlines
function getUpcomingDeadlines($conn, $limit = 5) {
    $query = "SELECT p.*, c.clubName 
              FROM paperwork p
              JOIN club c ON p.clubID = c.clubID
              WHERE p.status IN ('Dihantar', 'Disemak')
              AND p.created_at <= DATE_SUB(NOW(), INTERVAL 5 DAY)
              ORDER BY p.created_at ASC 
              LIMIT ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Get club activity statistics
function getClubStats($conn) {
    $query = "SELECT c.clubDimension, 
                     COUNT(p.id) as submission_count,
                     COUNT(CASE WHEN p.status = 'Diluluskan' THEN 1 END) as approved_count
              FROM club c
              LEFT JOIN paperwork p ON c.clubID = p.clubID
              GROUP BY c.clubDimension";
    
    $result = $conn->query($query);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Fetch all data
$paperworkStats = getPaperworkStats($conn);
$recentSubmissions = getRecentSubmissions($conn);
$upcomingDeadlines = getUpcomingDeadlines($conn);
$clubStats = getClubStats($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - PPMS</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <style>
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .stat-card {
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gray-100">
    <?php include('admin_sidebar.php'); ?>

    <div class="main-content">
        <!-- Quick Stats -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div class="stat-card bg-blue-500 text-white rounded-lg p-4">
                <h3 class="text-sm font-medium">Pending Review</h3>
                <p class="text-2xl font-bold"><?php echo $paperworkStats['pending_review']; ?></p>
            </div>
            <div class="stat-card bg-yellow-500 text-white rounded-lg p-4">
                <h3 class="text-sm font-medium">In Review</h3>
                <p class="text-2xl font-bold"><?php echo $paperworkStats['in_review']; ?></p>
            </div>
            <div class="stat-card bg-green-500 text-white rounded-lg p-4">
                <h3 class="text-sm font-medium">Approved</h3>
                <p class="text-2xl font-bold"><?php echo $paperworkStats['approved']; ?></p>
            </div>
            <div class="stat-card bg-red-500 text-white rounded-lg p-4">
                <h3 class="text-sm font-medium">Rejected</h3>
                <p class="text-2xl font-bold"><?php echo $paperworkStats['rejected']; ?></p>
            </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Recent Submissions -->
            <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-semibold mb-4">Recent Submissions</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-2 text-left">Club</th>
                                <th class="px-4 py-2 text-left">Program</th>
                                <th class="px-4 py-2 text-left">Status</th>
                                <th class="px-4 py-2 text-left">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($recentSubmissions as $submission): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?php echo htmlspecialchars($submission['clubName']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($submission['program_name']); ?></td>
                                <td class="px-4 py-2">
                                    <span class="px-2 py-1 rounded-full text-xs 
                                        <?php echo match($submission['status']) {
                                            'Dihantar' => 'bg-blue-100 text-blue-800',
                                            'Disemak' => 'bg-yellow-100 text-yellow-800',
                                            'Diluluskan' => 'bg-green-100 text-green-800',
                                            'Ditolak' => 'bg-red-100 text-red-800',
                                            default => 'bg-gray-100 text-gray-800'
                                        }; ?>">
                                        <?php echo htmlspecialchars($submission['status']); ?>
                                    </span>
                                </td>
                                <td class="px-4 py-2"><?php echo date('d/m/Y', strtotime($submission['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Upcoming Deadlines -->
            <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-semibold mb-4">Approaching Deadlines</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-2 text-left">Club</th>
                                <th class="px-4 py-2 text-left">Program</th>
                                <th class="px-4 py-2 text-left">Waiting Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($upcomingDeadlines as $deadline): ?>
                            <tr class="border-b">
                                <td class="px-4 py-2"><?php echo htmlspecialchars($deadline['clubName']); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($deadline['program_name']); ?></td>
                                <td class="px-4 py-2">
                                    <?php 
                                    $days = floor((time() - strtotime($deadline['created_at'])) / (60 * 60 * 24));
                                    $colorClass = $days > 7 ? 'text-red-600' : 'text-yellow-600';
                                    echo "<span class='font-medium {$colorClass}'>{$days} days</span>";
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Club Activity Chart -->
            <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-semibold mb-4">Club Activity by Dimension</h3>
                <canvas id="clubActivityChart"></canvas>
            </div>

            <!-- Status Distribution -->
            <div class="bg-white rounded-lg shadow-sm p-4">
                <h3 class="text-lg font-semibold mb-4">Paperwork Status Distribution</h3>
                <canvas id="statusChart"></canvas>
            </div>
        </div>
    </div>

    <script>
        // Club Activity Chart
        new Chart(document.getElementById('clubActivityChart'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($clubStats, 'clubDimension')); ?>,
                datasets: [{
                    label: 'Total Submissions',
                    data: <?php echo json_encode(array_column($clubStats, 'submission_count')); ?>,
                    backgroundColor: '#60A5FA'
                }, {
                    label: 'Approved',
                    data: <?php echo json_encode(array_column($clubStats, 'approved_count')); ?>,
                    backgroundColor: '#34D399'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Status Distribution Chart
        new Chart(document.getElementById('statusChart'), {
            type: 'doughnut',
            data: {
                labels: ['Pending Review', 'In Review', 'Approved', 'Rejected'],
                datasets: [{
                    data: [
                        <?php echo $paperworkStats['pending_review']; ?>,
                        <?php echo $paperworkStats['in_review']; ?>,
                        <?php echo $paperworkStats['approved']; ?>,
                        <?php echo $paperworkStats['rejected']; ?>
                    ],
                    backgroundColor: ['#60A5FA', '#FBBF24', '#34D399', '#EF4444']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>
</body>
</html>