<?php
session_start();
require_once '../../connection.php';

// Check admin session
if (!isset($_SESSION['staffRole']) || $_SESSION['staffRole'] !== 'Admin') {
    header('Location: ../staff_login.php');
    exit();
}

// Add new staff
if (isset($_POST['add_staff'])) {
    $staffFName = $_POST['staffFName'];
    $staffUsername = $_POST['staffUsername'];
    $staffPassword = password_hash($_POST['staffPassword'], PASSWORD_DEFAULT);
    $staffRole = $_POST['staffRole'];

    $stmt = $conn->prepare("INSERT INTO staff (staffFName, staffUsername, staffPassword, staffRole) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $staffFName, $staffUsername, $staffPassword, $staffRole);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Staff added successfully";
    } else {
        $_SESSION['error'] = "Error adding staff";
    }
    header('Location: staff_management.php');
    exit();
}

// Update staff
if (isset($_POST['update_staff'])) {
    $staffID = $_POST['staffID'];
    $staffFName = $_POST['staffFName'];
    $staffUsername = $_POST['staffUsername'];
    $staffRole = $_POST['staffRole'];
    
    if (!empty($_POST['staffPassword'])) {
        // If password is provided, update it
        $staffPassword = password_hash($_POST['staffPassword'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE staff SET staffFName=?, staffUsername=?, staffPassword=?, staffRole=? WHERE staffID=?");
        $stmt->bind_param("ssssi", $staffFName, $staffUsername, $staffPassword, $staffRole, $staffID);
    } else {
        // If no password provided, update other fields only
        $stmt = $conn->prepare("UPDATE staff SET staffFName=?, staffUsername=?, staffRole=? WHERE staffID=?");
        $stmt->bind_param("sssi", $staffFName, $staffUsername, $staffRole, $staffID);
    }
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Staff updated successfully";
    } else {
        $_SESSION['error'] = "Error updating staff";
    }
    header('Location: staff_management.php');
    exit();
}

// Delete staff
if (isset($_POST['delete_staff'])) {
    $staffID = $_POST['staffID'];
    
    $stmt = $conn->prepare("DELETE FROM staff WHERE staffID=?");
    $stmt->bind_param("i", $staffID);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Staff deleted successfully";
    } else {
        $_SESSION['error'] = "Error deleting staff";
    }
    header('Location: staff_management.php');
    exit();
}

// Fetch all staff
$result = $conn->query("SELECT * FROM staff ORDER BY staffID");
$staff = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management - PPMS</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <?php include('admin_sidebar.php'); ?>

    <div class="main-content ml-64 p-6">
        <h1 class="text-2xl font-bold mb-6">Staff Management</h1>

        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                <?php 
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>

        <!-- Add Staff Form -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 class="text-xl font-semibold mb-4">Add New Staff</h2>
            <form action="" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Staff Name</label>
                    <input type="text" name="staffFName" required 
                           class="w-full px-3 py-2 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Username</label>
                    <input type="text" name="staffUsername" required 
                           class="w-full px-3 py-2 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Password</label>
                    <input type="password" name="staffPassword" required 
                           class="w-full px-3 py-2 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Role</label>
                    <select name="staffRole" required class="w-full px-3 py-2 border rounded-lg">
                        <option value="admin">Admin</option>
                        <option value="staff">Staff</option>
                    </select>
                </div>
                <div class="md:col-span-2">
                    <button type="submit" name="add_staff" 
                            class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                        Add Staff
                    </button>
                </div>
            </form>
        </div>

        <!-- Staff List -->
        <div class="bg-white rounded-lg shadow-sm p-6">
            <h2 class="text-xl font-semibold mb-4">Staff List</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left">ID</th>
                            <th class="px-4 py-2 text-left">Name</th>
                            <th class="px-4 py-2 text-left">Username</th>
                            <th class="px-4 py-2 text-left">Role</th>
                            <th class="px-4 py-2 text-left">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($staff as $member): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?php echo htmlspecialchars($member['staffID']); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($member['staffFName']); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($member['staffUsername']); ?></td>
                            <td class="px-4 py-2"><?php echo htmlspecialchars($member['staffRole']); ?></td>
                            <td class="px-4 py-2">
                                <button onclick="editStaff(<?php echo htmlspecialchars(json_encode($member)); ?>)"
                                        class="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600 mr-2">
                                    Edit
                                </button>
                                <form action="" method="POST" class="inline">
                                    <input type="hidden" name="staffID" value="<?php echo $member['staffID']; ?>">
                                    <button type="submit" name="delete_staff" onclick="return confirm('Are you sure?')"
                                            class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">
                                        Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Edit Staff Modal -->
        <div id="editModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden">
            <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                <h2 class="text-xl font-semibold mb-4">Edit Staff</h2>
                <form action="" method="POST">
                    <input type="hidden" name="staffID" id="edit_staffID">
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">Staff Name</label>
                        <input type="text" name="staffFName" id="edit_staffFName" required 
                               class="w-full px-3 py-2 border rounded-lg">
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">Username</label>
                        <input type="text" name="staffUsername" id="edit_staffUsername" required 
                               class="w-full px-3 py-2 border rounded-lg">
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">New Password (leave blank to keep current)</label>
                        <input type="password" name="staffPassword" 
                               class="w-full px-3 py-2 border rounded-lg">
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-1">Role</label>
                        <select name="staffRole" id="edit_staffRole" required 
                                class="w-full px-3 py-2 border rounded-lg">
                            <option value="admin">Admin</option>
                            <option value="staff">CA</option>
                        </select>
                    </div>
                    <div class="flex justify-end gap-4">
                        <button type="button" onclick="closeEditModal()"
                                class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600">
                            Cancel
                        </button>
                        <button type="submit" name="update_staff"
                                class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function editStaff(staff) {
            document.getElementById('editModal').classList.remove('hidden');
            document.getElementById('edit_staffID').value = staff.staffID;
            document.getElementById('edit_staffFName').value = staff.staffFName;
            document.getElementById('edit_staffUsername').value = staff.staffUsername;
            document.getElementById('edit_staffRole').value = staff.staffRole;
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }
    </script>
</body>
</html>