<?php
session_start();

if (!isset($_SESSION['staffID']) || $_SESSION['staffRole'] !== 'CA') {
    echo "Unauthorized access!";
    exit();
}

include('../../connection.php');

// Process Add Student
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $clubID = $_POST['clubID'];
    $studentID = $_POST['student_id'];
    $role = $_POST['role'];

    // Verify advisor's permission
    $verify_sql = "SELECT 1 FROM club_advisors WHERE staffID = ? AND clubID = ?";
    $stmt = $conn->prepare($verify_sql);
    $stmt->bind_param("ii", $_SESSION['staffID'], $clubID);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        $insert_sql = "INSERT INTO club_members (clubID, student_id, role) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("iis", $clubID, $studentID, $role);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Student successfully added to the club";
        } else {
            $_SESSION['error'] = "Error adding student: " . $conn->error;
        }
    }
    header("Location: ca_club_assoc.php");
    exit();
}

// Process Edit Role
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'edit') {
    $clubID = $_POST['clubID'];
    $studentID = $_POST['student_id'];
    $newRole = $_POST['role'];

    $verify_sql = "SELECT 1 FROM club_advisors ca 
                   JOIN club_members cm ON ca.clubID = cm.clubID 
                   WHERE ca.staffID = ? AND cm.clubID = ? AND cm.student_id = ?";
    $stmt = $conn->prepare($verify_sql);
    $stmt->bind_param("iii", $_SESSION['staffID'], $clubID, $studentID);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        $update_sql = "UPDATE club_members SET role = ? 
                      WHERE clubID = ? AND student_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("sii", $newRole, $clubID, $studentID);
        
        if ($stmt->execute()) {
            $_SESSION['success'] = "Student role updated successfully";
        } else {
            $_SESSION['error'] = "Error updating role: " . $conn->error;
        }
    }
    header("Location: ca_club_assoc.php");
    exit();
}

// Process Remove Students
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'remove') {
    if (isset($_POST['selectedStudents'])) {
        $success = true;
        foreach ($_POST['selectedStudents'] as $data) {
            list($clubID, $studentID) = explode(',', $data);
            
            $verify_sql = "SELECT 1 FROM club_advisors ca 
                          JOIN club_members cm ON ca.clubID = cm.clubID 
                          WHERE ca.staffID = ? AND cm.clubID = ? AND cm.student_id = ?";
            $stmt = $conn->prepare($verify_sql);
            $stmt->bind_param("iii", $_SESSION['staffID'], $clubID, $studentID);
            $stmt->execute();
            
            if ($stmt->get_result()->num_rows > 0) {
                $delete_sql = "DELETE FROM club_members 
                              WHERE clubID = ? AND student_id = ?";
                $stmt = $conn->prepare($delete_sql);
                $stmt->bind_param("ii", $clubID, $studentID);
                if (!$stmt->execute()) {
                    $success = false;
                    break;
                }
            }
        }
        $_SESSION['success'] = $success ? "Selected students removed successfully" : "Error removing some students";
    }
    header("Location: ca_club_assoc.php");
    exit();
}

// Fetch advisor's clubs
$clubs_sql = "SELECT c.clubID, c.clubName 
              FROM club c 
              JOIN club_advisors ca ON c.clubID = ca.clubID 
              WHERE ca.staffID = ?";
$stmt = $conn->prepare($clubs_sql);
$stmt->bind_param("i", $_SESSION['staffID']);
$stmt->execute();
$clubs_result = $stmt->get_result();

// Fetch available students
$students_sql = "SELECT s.* FROM students s 
                WHERE s.student_id NOT IN (
                    SELECT cm.student_id 
                    FROM club_members cm 
                    JOIN club_advisors ca ON cm.clubID = ca.clubID 
                    WHERE ca.staffID = ?)";
$stmt = $conn->prepare($students_sql);
$stmt->bind_param("i", $_SESSION['staffID']);
$stmt->execute();
$students_result = $stmt->get_result();

// Fetch current club members
$members_sql = "SELECT cm.clubID, cm.student_id, s.name, c.clubName, 
                cm.role 
                FROM club_members cm
                JOIN students s ON cm.student_id = s.student_id
                JOIN club c ON cm.clubID = c.clubID
                JOIN club_advisors ca ON c.clubID = ca.clubID
                WHERE ca.staffID = ?";
$stmt = $conn->prepare($members_sql);
$stmt->bind_param("i", $_SESSION['staffID']);
$stmt->execute();
$members_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Student Management</title>
    <link rel="stylesheet" href="club_homepage.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <?php include('ca_sidebar.php'); ?>
    <main>
        <div class="content-wrapper">
            <!-- Header Section -->
            <div class="header-section">
                <div class="welcome-card">
                    <div class="welcome-text">
                        <h1><b>Club and Association Management</b></h1>
                    </div>
                </div>
            </div>

            <div class="main-content">
                <!-- Student Management Section -->
                <section class="dashboard">
                    <h2><i class="fa fa-users" aria-hidden="true"></i> Club Members</h2>
                    <div class="action-buttons">
                        <button onclick="toggleAddForm()" class="btn-large add-btn">Add New Student</button>
                        <button onclick="toggleDelete()" id="deleteStudentBtn" class="btn-large delete-btn">Remove Student</button>
                        <button onclick="confirmDelete()" id="confirmDeleteBtn" class="btn-large delete-btn" style="display:none;">Confirm Remove</button>
                        <button onclick="cancelDelete()" id="cancelDeleteBtn" class="btn-large cancel-btn" style="display:none;">Cancel</button>
                    </div>

                    <form id="deleteForm" action="ca_club_assoc.php" method="POST">
                        <input type="hidden" name="action" value="remove">
                        <div class="table-container">
                            <table id="studentTable">
                                <thead>
                                    <tr>
                                        <th class="checkbox-column" style="display: none;">
                                            <input type="checkbox" id="selectAll" onclick="toggleSelectAll()">
                                        </th>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Club</th>
                                        <th>Role</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($member = $members_result->fetch_assoc()): ?>
                                        <tr>
                                            <td class="checkbox-column" style="display: none;">
                                                <input type="checkbox" name="selectedStudents[]" 
                                                    value="<?php echo $member['clubID'].','.$member['student_id']; ?>" 
                                                    class="select-student" 
                                                    onchange="updateRowBackground(this)">
                                            </td>
                                            <td><?php echo htmlspecialchars($member['student_id']); ?></td>
                                            <td><?php echo htmlspecialchars($member['name']); ?></td>
                                            <td><?php echo htmlspecialchars($member['clubName']); ?></td>
                                            <td><?php echo htmlspecialchars($member['role']); ?></td>
                                            <td>
                                                <button type="button" 
                                                        onclick="showEditRole('<?php echo $member['clubID']; ?>', 
                                                                            '<?php echo $member['student_id']; ?>', 
                                                                            '<?php echo $member['role']; ?>')" 
                                                        class="btn-small edit-btn">Edit Role</button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </section>

                <!-- Add Student Modal -->
                <div id="addStudentForm" class="modal" style="display: none;">
                    <form action="ca_club_assoc.php" method="POST">
                        <h2>Add New Student</h2>
                        <input type="hidden" name="action" value="add">
                        
                        <div class="form-group">
                            <label for="clubID">Select Club:</label>
                            <select name="clubID" required>
                                <?php 
                                // Reset the result pointer
                                $clubs_result->data_seek(0);
                                while ($club = $clubs_result->fetch_assoc()): 
                                ?>
                                    <option value="<?php echo $club['clubID']; ?>">
                                        <?php echo htmlspecialchars($club['clubName']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="student_id">Select Student:</label>
                            <select name="student_id" required>
                                <?php 
                                // Reset the result pointer
                                $students_result->data_seek(0);
                                while ($student = $students_result->fetch_assoc()): 
                                ?>
                                    <option value="<?php echo $student['student_id']; ?>">
                                        <?php echo htmlspecialchars($student['name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="role">Role:</label>
                            <input type="text" name="role" required maxlength="100" placeholder="Enter role">
                        </div>

                        <div class="button-group">
                            <button type="button" onclick="closeAddForm()" class="btn-secondary">Cancel</button>
                            <button type="submit" class="btn-primary">Add Student</button>
                        </div>
                    </form>
                </div>

                <!-- Edit Role Modal -->
                <div id="editRoleDialog" class="modal" style="display:none;">
                    <form action="ca_club_assoc.php" method="POST">
                        <h2>Edit Member Role</h2>
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="clubID" id="editClubID">
                        <input type="hidden" name="student_id" id="editStudentID">
                        
                        <div class="form-group">
                            <label for="role">New Role:</label>
                            <input type="text" name="role" id="editRole" required maxlength="100" placeholder="Enter new role">
                        </div>

                        <div class="button-group">
                            <button type="button" onclick="closeEditDialog()" class="btn-secondary">Cancel</button>
                            <button type="submit" class="btn-primary">Update Role</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <style>
        /* Base Layout */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
        }

        .content-wrapper {
            margin-left: 230px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* Header Section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 20px;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        h2 {
            font-size: 1.5em;
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-bottom: 30px;
            margin-left: 30px;
        }

        /* Table Styles */
        .table-container {
            margin-top: 20px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #0061f2;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        /* Button Styles */
        .btn-primary, .btn-secondary, .btn-small, .btn-large {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .add-btn {
            background-color: #4CAF50;
            color: white;
        }

        .delete-btn {
            background-color: #f44336;
            color: white;
        }

        .edit-btn {
            background-color: #0061f2;
            color: white;
        }

        .cancel-btn {
            background-color: #6c757d;
            color: white;
        }

        /* Modal Styles Continued */
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            max-width: 500px;
            width: 90%;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #0061f2;
            box-shadow: 0 0 0 2px rgba(0, 97, 242, 0.1);
        }

        /* Button Group */
        .button-group {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        /* Action Buttons */
        .action-buttons {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }

        /* Checkbox Styles */
        .checkbox-column {
            width: 40px;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .content-wrapper {
                margin-left: 0;
                padding: 10px;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn-large {
                width: 100%;
            }

            .table-container {
                overflow-x: auto;
            }
        }
    </style>

    <script>
        // Add Student Form Functions
        function toggleAddForm() {
            const form = document.getElementById('addStudentForm');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }

        function closeAddForm() {
            document.getElementById('addStudentForm').style.display = 'none';
        }

        // Edit Role Functions
        function showEditRole(clubID, studentID, currentRole) {
            document.getElementById('editClubID').value = clubID;
            document.getElementById('editStudentID').value = studentID;
            document.getElementById('editRole').value = currentRole;
            document.getElementById('editRoleDialog').style.display = 'block';
        }

        function closeEditDialog() {
            document.getElementById('editRoleDialog').style.display = 'none';
        }

        // Delete Functions
        function toggleDelete() {
            const checkboxColumns = document.querySelectorAll('.checkbox-column');
            checkboxColumns.forEach(col => col.style.display = 'table-cell');
            
            document.getElementById('deleteStudentBtn').style.display = 'none';
            document.getElementById('confirmDeleteBtn').style.display = 'inline-block';
            document.getElementById('cancelDeleteBtn').style.display = 'inline-block';
        }

        function cancelDelete() {
            const checkboxColumns = document.querySelectorAll('.checkbox-column');
            checkboxColumns.forEach(col => col.style.display = 'none');
            
            document.getElementById('deleteStudentBtn').style.display = 'inline-block';
            document.getElementById('confirmDeleteBtn').style.display = 'none';
            document.getElementById('cancelDeleteBtn').style.display = 'none';
            
            // Uncheck all checkboxes
            document.querySelectorAll('.select-student').forEach(checkbox => {
                checkbox.checked = false;
                updateRowBackground(checkbox);
            });
            document.getElementById('selectAll').checked = false;
        }

        function confirmDelete() {
            const selectedCheckboxes = document.querySelectorAll('.select-student:checked');
            
            if (selectedCheckboxes.length === 0) {
                Swal.fire({
                    title: 'No Selection',
                    text: 'Please select at least one student to remove.',
                    icon: 'warning'
                });
                return;
            }

            Swal.fire({
                title: 'Confirm Removal',
                text: `Are you sure you want to remove ${selectedCheckboxes.length} student(s)?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, remove',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('deleteForm').submit();
                }
            });
        }

        // Checkbox Functions
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('.select-student');
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAll.checked;
                updateRowBackground(checkbox);
            });
        }

        function updateRowBackground(checkbox) {
            const row = checkbox.closest('tr');
            row.style.backgroundColor = checkbox.checked ? '#f0f0f0' : '';
        }

        // Success/Error Messages
        window.onload = function() {
            <?php if (isset($_SESSION['success'])): ?>
                Swal.fire({
                    title: 'Success!',
                    text: '<?php echo $_SESSION['success']; ?>',
                    icon: 'success',
                    timer: 3000,
                    showConfirmButton: false
                });
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                Swal.fire({
                    title: 'Error!',
                    text: '<?php echo $_SESSION['error']; ?>',
                    icon: 'error',
                    timer: 3000,
                    showConfirmButton: false
                });
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
        };
    </script>
</body>
</html>