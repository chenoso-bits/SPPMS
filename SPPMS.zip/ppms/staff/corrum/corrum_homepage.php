<?php
    // Start session
    session_start();

    if (!isset($_SESSION['staffID']) || !isset($_SESSION['staffRole'])) {
        echo "Session for staffID or staffRole is not set!";
        exit();
    }
    
    // Database connection
    include('../../connection.php');

    // Check if the connection is successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Initialize filter values
    $searchTitle = $_GET['searchTitle'] ?? '';
    $searchDate = $_GET['searchDate'] ?? '';
    $searchClub = $_GET['searchClub'] ?? '';

    // Query to fetch paperwork and club details with filters for status 'Disemak' and category 'JHEPA'
    $sql = "SELECT p.program_name, p.created_at, p.status, p.id, p.category, c.clubName
        FROM paperwork p
        JOIN club c ON c.clubID = p.clubID
        WHERE p.program_name LIKE ? AND p.created_at LIKE ? AND p.status = 'Disemak' AND p.category = 'JHEPA' AND c.clubName LIKE ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $likeTitle = "%$searchTitle%";
    $likeDate = "%$searchDate%";
    $likeClub = "%$searchClub%";
    $stmt->bind_param("sss", $likeTitle, $likeDate, $likeClub);

    // Execute the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the results
    $paperwork = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $paperwork[] = [
                'programName' => $row['program_name'],
                'category' => $row['category'],
                'submissionDate' => $row['created_at'],
                'status' => $row['status'],
                'id' => $row['id'],
                'clubName' => $row['clubName']
            ];
        }
    }
    
    // Close the statement and connection
    $stmt->close();
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
</head>
<body>
    <?php include('corrum_sidebar.php'); ?>
    
    <div class="content-wrapper">
        <!-- Welcome Section -->
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1>Welcome, <strong><?php echo htmlspecialchars($_SESSION['staffFName']); ?>!</strong></h1>
                    <p class="role-text">Role: <strong><?php echo htmlspecialchars($_SESSION['staffRole']); ?></strong></p>
                </div>
            </div>
        </div>

        <div class="main-content">
            <!-- Filter Section -->
            <div class="filter-container">
                <div class="section-header">
                    <h2><i class="fas fa-filter"></i> Filter Options</h2>
                </div>
                <form method="GET" action="" class="filter-form">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="searchTitle">
                                <i class="fas fa-heading"></i> Program Name
                            </label>
                            <input type="text" id="searchTitle" name="searchTitle" 
                                   value="<?php echo htmlspecialchars($searchTitle); ?>">
                        </div>
                        <div class="filter-group">
                            <label for="searchDate">
                                <i class="fas fa-calendar-alt"></i> Submission Date
                            </label>
                            <input type="date" id="searchDate" name="searchDate" 
                                   value="<?php echo htmlspecialchars($searchDate); ?>">
                        </div>
                        <div class="filter-group">
                            <label for="searchClub">
                                <i class="fas fa-users"></i> Club
                            </label>
                            <input type="text" id="searchClub" name="searchClub" 
                                   value="<?php echo htmlspecialchars($searchClub); ?>">
                        </div>
                        <div class="filter-buttons">
                            <button type="submit" class="apply-filter-btn">
                                <i class="fas fa-search"></i> Apply Filter
                            </button>
                            <button type="button" onclick="window.location.href='corrum_homepage.php'" class="clear-filter-btn">
                                <i class="fas fa-undo"></i> Clear Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Paperwork List Section -->
            <div class="paperwork-section">
                <div class="section-header">
                    <h2><i class="fas fa-clipboard-list"></i> Paperwork List</h2>
                </div>
                <div class="table-container">
                    <table id="paperworkTable" class="display responsive nowrap">
                        <thead>
                            <tr>
                                <th>Program Name</th>
                                <th>Category</th>
                                <th>Submission Data</th>
                                <th>Status</th>
                                <th>Club</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($paperwork)): ?>
                                <?php foreach ($paperwork as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['programName']); ?></td>
                                        <td><?php echo htmlspecialchars($item['category']); ?></td>
                                        <td><?php echo htmlspecialchars($item['submissionDate']); ?></td>
                                        <td>
                                            <span class="status-badge <?php echo strtolower(htmlspecialchars($item['status'])); ?>">
                                                <?php echo htmlspecialchars($item['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($item['clubName']); ?></td>
                                        <td>
                                            <a href="corrum_view_paperwork.php?id=<?php echo htmlspecialchars($item['id']); ?>" 
                                               class="action-btn">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6">No paperwork found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Base Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* Header Section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 30px;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: -10px 0 0 20px;
            font-size: 2.5em;
            font-weight: 600;
        }

        .role-text {
            margin: 10px 0 0 20px;
            font-size: 1.2em;
            opacity: 0.9;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-bottom: 30px;
            margin-left: 20px;
        }

        /* Filter Section */
        .filter-container {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }

        .section-header {
            margin-bottom: 20px;
        }

        .section-header h2 {
            color: #0061f2;
            font-size: 1.5em;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filter-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .filter-row {
            display: flex;
            gap: 30px; /* Increased gap between filter elements */
            flex-wrap: wrap;
            align-items: flex-start; /* Align items to top */
            padding: 0 20px; /* Added horizontal padding */
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
            margin-bottom: 20px; /* Added bottom margin */
        }

        .filter-group label {
            display: block;
            margin-bottom: 12px; /* Increased margin below labels */
            color: #495057;
            font-weight: 500;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 8px;
            font-size: 0.9em;
        }

        .filter-buttons {
            display: flex;
            gap: 15px; /* Increased gap between buttons */
            align-items: flex-end;
            margin-top: 30px; /* Added top margin to buttons container */
            padding-bottom: 20px; /* Added bottom padding */
        }

        .apply-filter-btn,
        .clear-filter-btn {
            padding: 12px 24px; /* Increased button padding */
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            min-width: 120px; /* Added minimum width to buttons */
            justify-content: center; /* Center button content */
        }

        .apply-filter-btn {
            background: #0061f2;
            color: white;
        }

        .clear-filter-btn {
            background: #6c757d;
            color: white;
        }

        .apply-filter-btn:hover,
        .clear-filter-btn:hover {
            transform: translateY(-2px);
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .content-wrapper {
                margin-left: 0;
            }
            
            .filter-row {
                flex-direction: column;
                gap: 20px; /* Adjusted gap for mobile */
                padding: 0 10px; /* Reduced padding for mobile */
            }

            .filter-group {
                width: 100%;
                margin-bottom: 15px; /* Adjusted margin for mobile */
            }

            .filter-buttons {
                width: 100%;
                flex-direction: row; /* Keep buttons in a row on mobile */
                justify-content: center; /* Center buttons on mobile */
                gap: 10px; /* Adjusted gap for mobile */
            }

            .apply-filter-btn,
            .clear-filter-btn {
                flex: 1; /* Make buttons take equal width */
                max-width: 200px; /* Limit button width on mobile */
            }
        }

        /* Table Styles */
        .table-container {
            margin-top: 20px;
        }

        #paperworkTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        #paperworkTable th {
            background: #0061f2;
            color: white;
            padding: 15px;
            font-weight: 500;
        }

        #paperworkTable td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        /* Status Badges */
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .status-badge.disemak {
            background-color: #e8f4fd;
            color: #0d6efd;
        }

        /* Action Button */
        .action-btn {
            background: #e8f4fd;
            color: #0d6efd;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9em;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s ease;
        }

        .action-btn:hover {
            background: #0d6efd;
            color: white;
        }

        /* DataTables Styling */
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #ced4da;
            border-radius: 6px;
            padding: 6px 12px;
            margin-bottom: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin: 0 4px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #0061f2;
            border-color: #0061f2;
            color: white !important;
        }
    </style>

    <script>
        $(document).ready(function() {
            $('#paperworkTable').DataTable({
                responsive: true,
                pageLength: 10,
                language: {
                    search: "🔍 Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "«",
                        last: "»",
                        next: "→",
                        previous: "←"
                    }
                },
                columnDefs: [{
                    targets: -1,
                    orderable: false
                }],
                order: [[2, 'desc']]
            });
        });
    </script>
</body>
</html>