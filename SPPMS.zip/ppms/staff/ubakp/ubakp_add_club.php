<?php
// Start session
session_start();

if (!isset($_SESSION['staffID']) || !isset($_SESSION['staffRole'])) {
    echo "Session for staffID or staffRole is not set!";
    exit();
}

// Database connection
include('../../connection.php');

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all advisors from the database
$advisorQuery = "SELECT staffID, staffFName FROM staff WHERE staffRole = 'CA'";
$advisorResult = $conn->query($advisorQuery);
if (!$advisorResult) {
    die("Error fetching advisors: " . $conn->error);
}
$advisors = [];
if ($advisorResult->num_rows > 0) {
    while ($row = $advisorResult->fetch_assoc()) {
        $advisors[] = $row;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize form data
    $clubName = $_POST['clubName'];
    $clubDescription = $_POST['clubDescription'];
    $clubDimension = $_POST['clubDimension'];
    $advisorID = $_POST['advisorID'];
    $clubUsername = $_POST['clubUsername'];
    $clubPassword = $_POST['clubPassword']; // No hashing applied

    // Set clubType to 'club'
    $clubType = 'club';

    // Insert the new club into the database
    $sql = "INSERT INTO club (clubName, clubDescription, clubDimension, clubUsername, clubPassword, clubType) 
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $stmt->bind_param("ssssss", $clubName, $clubDescription, $clubDimension, $clubUsername, $clubPassword, $clubType);

    if ($stmt->execute()) {
        // Get the ID of the newly created club
        $clubID = $conn->insert_id;

        // Link the advisor to the club in the club_advisors table
        $advisorInsertSQL = "INSERT INTO club_advisors (clubID, staffID) VALUES (?, ?)";
        $advisorStmt = $conn->prepare($advisorInsertSQL);

        if (!$advisorStmt) {
            die("Error preparing advisor SQL statement: " . $conn->error);
        }

        $advisorStmt->bind_param("ii", $clubID, $advisorID);

        // Execute the statement
        if ($advisorStmt->execute()) {
            // Display a JavaScript popup message
            echo "<script>
                    alert('Club added successfully!');
                    window.location.href = 'ubakp_club_assoc.php'; // Redirect after clicking OK
                  </script>";
        } else {
            echo "Error assigning advisor: " . $advisorStmt->error;
        }

        // Close the statement
        $advisorStmt->close();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the main statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kelab Baru</title>
    <link rel="stylesheet" href="club_homepage.css">
    <style>
        /* General body styling */
        body {
            display: flex;
            flex-direction: row;
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }

        /* Sidebar styling */
        #sidebar {
            width: 250px;
            height: 100vh;
            background-color: #333;
            color: white;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            box-sizing: border-box;
        }

        /* Main content area */
        main {
            margin-left: 250px; /* Offset to make space for the sidebar */
            padding: 20px;
            width: calc(100% - 250px); /* Ensures main content takes the remaining width */
            box-sizing: border-box;
            display: flex;
            justify-content: center; /* Center the content horizontally */
            align-items: center; /* Center the content vertically */
            min-height: 100vh; /* Ensure it takes full height */
        }

        /* Form container styling */
        .form-container {
            background-color: #fff;
            padding: 30px; /* Increased padding for better spacing */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%; /* Full width of the main area */
            max-width: 600px; /* Limit the maximum width */
        }

        /* Add spacing for form elements */
        form {
            display: flex;
            flex-direction: column;
        }

        /* Form input styling */
        input, select, textarea {
            width: 100%;
            padding: 12px; /* Increased padding for better spacing */
            margin: 10px 0; /* Adjusted margin for better spacing */
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box; /* Ensure padding is included in width */
            font-size: 16px; /* Increased font size for better readability */
        }

        /* Submit and Cancel buttons styling */
        .form-actions {
            display: flex;
            justify-content: space-between;
        }

        button {
            padding: 12px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px; /* Increased font size for better readability */
            transition: background-color 0.3s; /* Smooth transition for hover effect */
        }

        button:hover {
            background-color: #0056b3;
        }

        .btn-cancel {
            padding: 12px 20px;
            background-color: #f44336;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 16px; /* Increased font size for better readability */
            transition: background-color 0.3s; /* Smooth transition for hover effect */
        }

        .btn-cancel:hover {
            background-color: #e53935;
        }

        .form-group {
            margin-bottom: 20px; /* Increased margin for better spacing */
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold; /* Bold labels for better visibility */
        }

        .error {
            color: red;
            font-size: 0.875em;
        }

        /* Search results styling */
        #advisorResults {
            max-height: 150px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-top: 5px;
        }

        #advisorResults div {
            padding: 10px;
            cursor: pointer;
            border-bottom: 1px solid #ddd;
        }

        #advisorResults div:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
    <?php include('ubakp_sidebar.php'); ?>
    <main>
        <div class="form-container">
            <h1 style="margin-top: 0;">Add New Club</h1>
            <form action="ubakp_add_club.php" method="POST">
                <div class="form-group">
                    <label for="clubName">Club Name:</label>
                    <input type="text" id="clubName" name="clubName" required>
                </div>

                <div class="form-group">
                    <label for="clubDescription">Club Description:</label>
                    <textarea id="clubDescription" name="clubDescription" required></textarea>
                </div>

                <div class="form-group">
                    <label for="clubDimension">Club Dimension:</label>
                    <select id="clubDimension" name="clubDimension" required>
                        <option value="Pengurusan dan Kepimpinan">Pengurusan dan Kepimpinan</option>
                        <option value="Akademik dan Kerjaya">Akademik dan Kerjaya</option>
                        <option value="Etika dan Rohani">Etika dan Rohani</option>
                        <option value="Keusahawanan">Keusahawanan</option>
                        <option value="Teknikal dan Inovasi">Teknikal dan Inovasi</option>
                        <option value="Sukarelawan">Sukarelawan</option>
                        <option value="Budaya dan Entiti Nasional">Budaya dan Entiti Nasional</option>
                        <option value="Sukan dan Rekreasi">Sukan dan Rekreasi</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="advisorSearch">Club Advisor:</label>
                    <input type="text" id="advisorSearch" name="advisorSearch" placeholder="Search Advisor..." required>
                    <div id="advisorResults"></div>
                    <input type="hidden" id="advisorID" name="advisorID" required>
                </div>

                <div class="form-group">
                    <label for="clubUsername">Club Username:</label>
                    <input type="text" id="clubUsername" name="clubUsername" required>
                </div>

                <div class="form-group">
                    <label for="clubPassword">Club Password:</label>
                    <input type="text" id="clubPassword" name="clubPassword" required>
                </div>

                <div class="form-actions">
                    <button type="submit">Add</button>
                    <a href="ubakp_club_assoc.php" class="btn-cancel">Cancel</a>
                </div>
            </form>
        </div>
    </main>

    <script>
        const advisors = <?php echo json_encode($advisors); ?>;
        const advisorSearch = document.getElementById('advisorSearch');
        const advisorResults = document.getElementById('advisorResults');
        const advisorID = document.getElementById('advisorID');

        advisorSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            advisorResults.innerHTML = '';

            const filteredAdvisors = advisors.filter(advisor => 
                advisor.staffFName.toLowerCase().includes(searchTerm)
            );

            if (filteredAdvisors.length > 0) {
                filteredAdvisors.forEach(advisor => {
                    const div = document.createElement('div');
                    div.textContent = advisor.staffFName;
                    div.addEventListener('click', function() {
                        advisorSearch.value = advisor.staffFName;
                        advisorID.value = advisor.staffID;
                        advisorResults.innerHTML = '';
                    });
                    advisorResults.appendChild(div);
                });
            } else {
                const div = document.createElement('div');
                div.textContent = 'Tiada penasihat dijumpai';
                advisorResults.appendChild(div);
            }
        });
    </script>
</body>
</html>
