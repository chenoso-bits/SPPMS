<?php
    // Start session
    session_start();
    // Database connection
    include('../../connection.php');

    // Check if the connection is successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if (!isset($_SESSION['staffID']) || !isset($_SESSION['staffRole'])) {
        header("Location: staff_login.php");
        exit();
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clubId'])) {
        $clubId = $_POST['clubId'];
        
        try {
            // Start transaction
            $conn->begin_transaction();
            
            // Delete from related tables
            $tables = ['club_members', 'club_advisors', 'club'];
            $success = true;
            
            foreach ($tables as $table) {
                $stmt = $conn->prepare("DELETE FROM $table WHERE clubID = ?");
                if (!$stmt) {
                    throw new Exception("Prepare failed: " . $conn->error);
                }
                $stmt->bind_param("s", $clubId);
                if (!$stmt->execute()) {
                    throw new Exception("Execute failed: " . $stmt->error);
                }
                $stmt->close();
            }
            
            // Commit transaction
            $conn->commit();
            echo "success";
            
        } catch (Exception $e) {
            // Rollback on error
            $conn->rollback();
            error_log("Delete club error: " . $e->getMessage());
            echo "error";
        }
        exit();
    }

    // Initialize filter values
    $searchClub = $_GET['searchClub'] ?? '';
    $searchDimension = $_GET['searchDimension'] ?? '';

    // Query to fetch club details with filters
    $sql = "SELECT c.clubID, c.clubName, c.clubDescription, c.clubDimension, s.staffFName, 
            (SELECT COUNT(*) FROM club_members WHERE clubID = c.clubID) as memberCount
            FROM club c
            LEFT JOIN club_advisors ca ON c.clubID = ca.clubID
            LEFT JOIN staff s ON ca.staffID = s.staffID
            WHERE c.clubName LIKE ?";

    // Add condition for dimension if selected
    if ($searchDimension) {
        $sql .= " AND clubDimension = ?";
    }

    $stmt = $conn->prepare($sql);
    $likeClub = "%$searchClub%";

    if ($searchDimension) {
        $stmt->bind_param("ss", $likeClub, $searchDimension);
    } else {
        $stmt->bind_param("s", $likeClub);
    }

    // Execute the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the results
    $clubs = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $clubs[] = [
                'clubID' => $row['clubID'],
                'clubName' => $row['clubName'],
                'clubDimension' => $row['clubDimension'],
                'clubDescription' => $row['clubDescription'],
                'staffFName' => $row['staffFName'] ?? 'Not assigned',
                'memberCount' => $row['memberCount']
            ];
        }
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Club Details</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>
<body>
    <?php include('ubakp_sidebar.php'); ?>
    
    <div class="content-wrapper">
        <!-- Welcome Section -->
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1>Club and Association Management</h1>
                </div>
            </div>
        </div>

        <div class="main-content">
            <!-- Filter Section -->
            <div class="filter-container">
                <div class="section-header">
                    <h2><i class="fas fa-filter"></i> Filter Options</h2>
                </div>
                <form method="GET" action="club_assoc.php" class="filter-form">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="searchClub">
                                <i class="fas fa-users"></i> Club Name
                            </label>
                            <input type="text" id="searchClub" name="searchClub" 
                                   value="<?php echo htmlspecialchars($searchClub); ?>">
                        </div>
                        <div class="filter-group">
                            <label for="searchDimension">
                                <i class="fas fa-cube"></i> Dimension
                            </label>
                            <select id="searchDimension" name="searchDimension">
                                <option value="">Select Dimension</option>
                                <option value="Pengurusan dan Kepimpinan" <?php echo ($searchDimension == 'Pengurusan dan Kepimpinan' ? 'selected' : ''); ?>>Pengurusan dan Kepimpinan</option>
                                <option value="Akademik dan Kerjaya" <?php echo ($searchDimension == 'Akademik dan Kerjaya' ? 'selected' : ''); ?>>Akademik dan Kerjaya</option>
                                <option value="Etika dan Rohani" <?php echo ($searchDimension == 'Etika dan Rohani' ? 'selected' : ''); ?>>Etika dan Rohani</option>
                                <option value="Keusahawanan" <?php echo ($searchDimension == 'Keusahawanan' ? 'selected' : ''); ?>>Keusahawanan</option>
                                <option value="Teknikal dan Inovasi" <?php echo ($searchDimension == 'Teknikal dan Inovasi' ? 'selected' : ''); ?>>Teknikal dan Inovasi</option>
                                <option value="Sukarelawan" <?php echo ($searchDimension == 'Sukarelawan' ? 'selected' : ''); ?>>Sukarelawan</option>
                                <option value="Budaya dan Entiti Nasional" <?php echo ($searchDimension == 'Budaya dan Entiti Nasional' ? 'selected' : ''); ?>>Budaya dan Entiti Nasional</option>
                                <option value="Sukan dan Rekreasi" <?php echo ($searchDimension == 'Sukan dan Rekreasi' ? 'selected' : ''); ?>>Sukan dan Rekreasi</option>
                            </select>
                        </div>
                        <div class="filter-buttons">
                            <button type="submit" class="apply-filter-btn">
                                <i class="fas fa-search"></i> Apply Filter
                            </button>
                            <button type="button" onclick="window.location.href='ubakp_club_assoc.php'" class="clear-filter-btn">
                                <i class="fas fa-undo"></i> Clear Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Club List Section -->
            <div class="club-section">
                <div class="section-header">
                    <h2><i class="fas fa-users"></i> Registered Club and Association</h2>
                    <div class="action-buttons">
                        <a href="ubakp_add_club.php" class="btn-large add-btn">
                            <i class="fas fa-plus"></i> Add New Club
                        </a>
                    </div>
                </div>

                <form id="deleteForm" method="POST" action="ubakp_delete_club.php">
                    <table id="clubTable" class="display responsive nowrap">
                        <thead>
                            <tr>
                                <th style="text-align: center;">ID</th>
                                <th>Club Name</th>
                                <th>Dimension</th>
                                <th>Club Description</th>
                                <th>Advisor</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($clubs)): ?>
                                <?php foreach ($clubs as $club): ?>
                                    <tr>
                                        <td style="text-align: center;"><?php echo htmlspecialchars($club['clubID']); ?></td>
                                        <td><?php echo htmlspecialchars($club['clubName']); ?></td>
                                        <td>
                                            <span class="dimension-badge">
                                                <?php echo htmlspecialchars($club['clubDimension']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($club['clubDescription']); ?></td>
                                        <td><?php echo htmlspecialchars($club['staffFName']); ?></td>
                                        <td>
                                            <div class="action-buttons-container">
                                                <a href="ubakp_edit_club.php?id=<?php echo htmlspecialchars($club['clubID']); ?>" 
                                                class="action-btn edit-btn">
                                                    <i class="fas fa-edit"></i> Update
                                                </a>
                                                <button type="button" 
                                                        class="action-btn delete-btn"
                                                        onclick="deleteClub('<?php echo htmlspecialchars($club['clubID']); ?>', '<?php echo htmlspecialchars($club['clubName']); ?>')"
                                                        data-club-id="<?php echo htmlspecialchars($club['clubID']); ?>">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Wait for the DOM to be fully loaded
        document.addEventListener("DOMContentLoaded", function() {
            // Initialize DataTable with enhanced configuration
            $(document).ready(function() {
                const clubTable = $('#clubTable').DataTable({
                    responsive: true,
                    pageLength: 10,
                    language: {
                        search: "🔍 Search:",
                        lengthMenu: "Show _MENU_ entries",
                        info: "Showing _START_ to _END_ of _TOTAL_ entries",
                        paginate: {
                            first: "«",
                            last: "»",
                            next: "→",
                            previous: "←"
                        }
                    },
                    columnDefs: [
                        {
                            targets: -1, // Action column
                            orderable: false,
                            searchable: false,
                            width: "150px"
                        },
                        {
                            targets: 0, // ID column
                            width: "80px"
                        },
                        {
                            targets: 2, // Dimension column
                            width: "150px"
                        }
                    ],
                    order: [[1, 'asc']], // Sort by club name by default
                    dom: '<"top"lf>rt<"bottom"ip><"clear">', // Custom layout
                    drawCallback: function(settings) {
                        // Re-initialize any tooltips after table redraw
                        $('[data-toggle="tooltip"]').tooltip();
                    }
                });

                // Add responsive handling
                function adjustTableResponsiveness() {
                    const tableWrapper = document.querySelector('.dataTables_wrapper');
                    if (tableWrapper) {
                        if (window.innerWidth < 768) {
                            tableWrapper.classList.add('mobile-view');
                            clubTable.columns.adjust().responsive.recalc();
                        } else {
                            tableWrapper.classList.remove('mobile-view');
                            clubTable.columns.adjust().responsive.recalc();
                        }
                    }
                }

                // Initialize responsive handling
                adjustTableResponsiveness();
                window.addEventListener('resize', adjustTableResponsiveness);

                // Add filter functionality
                $('#searchClub').on('keyup', function() {
                    clubTable.search(this.value).draw();
                });

                $('#searchDimension').on('change', function() {
                    clubTable.column(2).search(this.value).draw();
                });

                // Error handling for DataTable operations
                $.fn.dataTable.ext.errMode = 'throw';
                clubTable.on('error.dt', function(e, settings, techNote, message) {
                    console.error('DataTable Error:', message);
                    Swal.fire({
                        title: 'Table Error',
                        text: 'An error occurred while processing the table. Please refresh the page.',
                        icon: 'error',
                        confirmButtonText: 'Refresh'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.reload();
                        }
                    });
                });
            });

            // Function to delete a club
            window.deleteClub = function(clubId, clubName) {
            Swal.fire({
                title: 'Delete Club',
                text: `Are you sure you want to delete ${clubName}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading state
                    Swal.showLoading();
                    
                    const formData = new FormData();
                    formData.append('clubId', clubId);

                    fetch('ubakp_club_assoc.php', {  // Change to current file
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.text();
                    })
                    .then(result => {
                        if (result.trim() === 'success') {
                            Swal.fire({
                                title: 'Deleted!',
                                text: `${clubName} has been deleted successfully.`,
                                icon: 'success'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            throw new Error('Delete operation failed');
                        }
                    })
                    .catch((error) => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'Error!',
                            text: 'Failed to delete the club. Please try again.',
                            icon: 'error'
                        });
                    });
                }
            });
        };

            // Handle filter form submission
            const filterForm = document.querySelector('.filter-form');
            if (filterForm) {
                filterForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const formData = new FormData(this);
                    const searchParams = new URLSearchParams(formData);
                    window.location.href = `${this.action}?${searchParams.toString()}`;
                });
            }

            // Handle clear filter button
            const clearFilterBtn = document.querySelector('.clear-filter-btn');
            if (clearFilterBtn) {
                clearFilterBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.location.href = 'ubakp_club_assoc.php';
                });
            }

            // Handle table responsiveness
            function handleTableResponsiveness() {
                const tableWrapper = document.querySelector('.dataTables_wrapper');
                if (tableWrapper) {
                    if (window.innerWidth < 768) {
                        tableWrapper.classList.add('mobile-view');
                    } else {
                        tableWrapper.classList.remove('mobile-view');
                    }
                }
            }

            // Initialize responsive handling
            handleTableResponsiveness();
            window.addEventListener('resize', handleTableResponsiveness);

            // Session timeout handling
            let sessionTimeout;
            function resetSessionTimeout() {
                clearTimeout(sessionTimeout);
                sessionTimeout = setTimeout(function() {
                    Swal.fire({
                        title: 'Session Expiring',
                        text: 'Your session is about to expire. Would you like to continue?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes, continue',
                        cancelButtonText: 'Logout',
                        reverseButtons: true
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Extend session
                            fetch('extend_session.php')
                            .then(() => {
                                Swal.fire({
                                    title: 'Session Extended',
                                    text: 'Your session has been extended successfully.',
                                    icon: 'success',
                                    timer: 1500,
                                    showConfirmButton: false
                                });
                            })
                            .catch(() => {
                                window.location.href = 'logout.php';
                            });
                        } else {
                            window.location.href = 'logout.php';
                        }
                    });
                }, 25 * 60 * 1000); // 25 minutes
            }

            // Initialize session timeout
            resetSessionTimeout();
            document.addEventListener('click', resetSessionTimeout);
            document.addEventListener('keypress', resetSessionTimeout);

            // Error handler for DataTable
            function handleDataTableError(error) {
                console.error('DataTable Error:', error);
                Swal.fire({
                    title: 'Table Loading Error',
                    text: 'There was an error loading the table. Please refresh the page.',
                    icon: 'error',
                    confirmButtonColor: '#dc3545',
                    confirmButtonText: 'Refresh Page'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.reload();
                    }
                });
            }

            // Add error handling for DataTable initialization
            try {
                if ($.fn.DataTable.isDataTable('#clubTable')) {
                    $('#clubTable').DataTable().destroy();
                    clubTable.draw();
                }
            } catch (error) {
                handleDataTableError(error);
            }

            // Handle AJAX loading states
            $(document)
                .ajaxStart(function() {
                    Swal.fire({
                        title: 'Loading...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        willOpen: () => {
                            Swal.showLoading();
                        }
                    });
                })
                .ajaxStop(function() {
                    Swal.close();
                });
        });
    </script>

    <style>
        /* Base Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* Header Section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 20px;
            color: white;
            display: flex;
            justify-content: center; /* Center the content */
            align-items: center;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
        }

        .role-text {
            margin: 10px 0 0;
            font-size: 1.2em;
            opacity: 0.9;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-bottom: 30px;
            padding-left: 50px;
        }

        /* Filter Section */
        .filter-container {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-header h2 {
            color: #0061f2;
            font-size: 1.25em;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filter-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .filter-row {
            display: flex;
            gap: 20px;
            align-items: flex-end;
        }

        .filter-group {
            flex: 1;
            margin: 0 10px 0 10px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 8px;
            color: #495057;
            font-weight: 500;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 8px;
            font-size: 0.9em;
        }

        /* Buttons */
        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .btn-large {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .add-btn {
            background: #20c997;
            color: white;
        }

        .action-btn.delete-btn {
            background: #fee2e2;
            color: #dc2626;
            margin-left: 8px;
            border: 0;
        }

        .cancel-btn {
            background: #6c757d;
            color: white;
        }

        .action-btn {
            background: #e8f4fd;
            color: #0d6efd;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9em;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s ease;
        }

        .action-btn:hover {
            background: #0d6efd;
            color: white;
        }

        .action-btn.delete-btn:hover {
            background: #dc2626;
            color: white;
        }

        /* Table Styles */
        #clubTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        #clubTable th {
            background: #0061f2;
            color: white;
            padding: 15px;
            font-weight: 500;
        }

        #clubTable td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        /* Dimension Badge */
        .dimension-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
            background-color: #e8f4fd;
            color: #0d6efd;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .content-wrapper {
                margin-left: 0;
            }
            
            .filter-row {
                flex-direction: column;
            }

            .filter-group {
                width: 100%;
            }
        }

        /* Delete mode specific styles */
        .delete-mode {
            position: relative;
        }

        .delete-mode::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(220, 53, 69, 0.05);
            border-radius: 8px;
            pointer-events: none;
        }

        /* Checkbox styles */
        .checkbox-cell input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            position: relative;
            margin: 0;
        }

        /* Selected row styling */
        .selected-for-delete {
            background-color: rgba(220, 53, 69, 0.1) !important;
            transition: background-color 0.3s ease;
        }

        .selected-for-delete:hover {
            background-color: rgba(220, 53, 69, 0.15) !important;
        }

        /* Delete button states */
        .delete-btn-active {
            background-color: #dc3545 !important;
            animation: pulseDelete 2s infinite;
        }

        @keyframes pulseDelete {
            0% {
                box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.4);
            }
            70% {
                box-shadow: 0 0 0 10px rgba(220, 53, 69, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(220, 53, 69, 0);
            }
        }

        /* Action button transitions */
        .btn-large {
            transition: all 0.3s ease;
        }

        .btn-large:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Loading state styles */
        .swal2-loading {
            background-color: rgba(255, 255, 255, 0.9);
        }

        /* Checkbox header alignment */
        #checkbox-header {
            text-align: center;
        }

        #selectAll {
            margin: 0;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .apply-filter-btn,
        .clear-filter-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .apply-filter-btn {
            background: #0061f2;
            color: white;
        }

        .clear-filter-btn {
            background: #6c757d;
            color: white;
        }

        .apply-filter-btn:hover,
        .clear-filter-btn:hover {
            transform: translateY(-2px);
        }

        /* DataTables Styling */
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #ced4da;
            border-radius: 6px;
            padding: 6px 12px;
            margin-bottom: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin: 0 4px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #0061f2;
            border-color: #0061f2;
            color: white !important;
        }

        .dataTables_wrapper .dataTables_info {
            padding-top: 1em;
        }

        /* Table Responsive Styles */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        @media screen and (max-width: 767px) {
            .dataTables_wrapper .dataTables_length,
            .dataTables_wrapper .dataTables_filter,
            .dataTables_wrapper .dataTables_info,
            .dataTables_wrapper .dataTables_paginate {
                text-align: left;
                float: none;
                margin-bottom: 10px;
            }
        }
    </style>
</body>
</html>
