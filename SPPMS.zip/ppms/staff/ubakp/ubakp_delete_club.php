<?php
// delete_club.php
header('Content-Type: application/json');

session_start();
if (!isset($_SESSION['staffID'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

include('../connection.php');

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $clubIds = $input['clubs'] ?? [];

    if (empty($clubIds)) {
        throw new Exception('No clubs selected for deletion');
    }

    $conn->begin_transaction();

    // Delete from related tables first
    $tables = ['club_members', 'club_advisors', 'club'];
    
    foreach ($tables as $table) {
        $placeholders = str_repeat('?,', count($clubIds) - 1) . '?';
        $sql = "DELETE FROM $table WHERE clubID IN ($placeholders)";
        $stmt = $conn->prepare($sql);
        $stmt->execute($clubIds);
    }

    $conn->commit();
    
    echo json_encode([
        'success' => true,
        'message' => count($clubIds) . ' club(s) successfully deleted'
    ]);

} catch (Exception $e) {
    if ($conn->connect_error === false) {
        $conn->rollback();
    }
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
} finally {
    if ($conn) {
        $conn->close();
    }
}
?>