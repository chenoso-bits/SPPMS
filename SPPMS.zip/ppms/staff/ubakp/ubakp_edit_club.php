<?php
// Start session
session_start();

// Check for staff authentication
if (!isset($_SESSION['staffID']) || !isset($_SESSION['staffRole'])) {
    $_SESSION['error_message'] = "Unauthorized access. Please log in.";
    header("Location: ../staff_login.php");
    exit();
}

// Database connection
include('../../connection.php');

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$errors = [];
$success_message = "";
$club = null;
$current_advisor = null;

// Fetch all advisors from the database
$advisorQuery = "SELECT s.staffID, s.staffFName FROM staff s WHERE s.staffRole = 'CA'";
$advisorResult = $conn->prepare($advisorQuery);
$advisorResult->execute();
$advisorResult = $advisorResult->get_result();

$advisors = [];
if ($advisorResult->num_rows > 0) {
    while ($row = $advisorResult->fetch_assoc()) {
        $advisors[] = $row;
    }
}

// Check if club ID is provided
if (isset($_GET['id'])) {
    $clubID = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    
    if ($clubID === false) {
        $_SESSION['error_message'] = "Invalid club ID";
        header("Location: ubakp_club_assoc.php");
        exit();
    }

    // Fetch club details with current advisor
    $clubQuery = "SELECT c.*, ca.staffID as advisorID, s.staffFName as advisorName 
                 FROM club c 
                 LEFT JOIN club_advisors ca ON c.clubID = ca.clubID 
                 LEFT JOIN staff s ON ca.staffID = s.staffID 
                 WHERE c.clubID = ?";
    
    $stmt = $conn->prepare($clubQuery);
    $stmt->bind_param("i", $clubID);
    $stmt->execute();
    $clubResult = $stmt->get_result();

    if ($clubResult->num_rows == 1) {
        $club = $clubResult->fetch_assoc();
        $current_advisor = [
            'staffID' => $club['advisorID'],
            'staffFName' => $club['advisorName']
        ];
    } else {
        $_SESSION['error_message'] = "Club not found!";
        header("Location: ubakp_club_assoc.php");
        exit();
    }
    $stmt->close();
} else {
    $_SESSION['error_message'] = "No club ID provided!";
    header("Location: ubakp_club_assoc.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect and sanitize form data
    $clubName = trim($_POST['clubName']);
    $clubDescription = trim($_POST['clubDescription']);
    $clubDimension = $_POST['clubDimension'];
    $advisorID = filter_var($_POST['advisorID'], FILTER_VALIDATE_INT);
    $clubUsername = trim($_POST['clubUsername']);
    $clubPassword = $_POST['clubPassword'];

    // Validation
    if (empty($clubName)) $errors[] = "Nama kelab diperlukan";
    if (empty($clubDescription)) $errors[] = "Deskripsi kelab diperlukan";
    if (!$advisorID) $errors[] = "Penasihat kelab diperlukan";
    if (empty($clubUsername)) $errors[] = "Nama pengguna diperlukan";

    if (empty($errors)) {
        // Begin transaction
        $conn->begin_transaction();
        try {
            // Update club details
            $sql = "UPDATE club SET 
                    clubName = ?, 
                    clubDescription = ?, 
                    clubDimension = ?,
                    clubUsername = ?,
                    clubPassword = ?
                    WHERE clubID = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssi", $clubName, $clubDescription, $clubDimension, $clubUsername, $clubPassword, $clubID);
            
            if (!$stmt->execute()) {
                throw new Exception("Error updating club details");
            }

            // Delete existing advisor if any
            $deleteAdvisor = "DELETE FROM club_advisors WHERE clubID = ?";
            $stmtDelete = $conn->prepare($deleteAdvisor);
            $stmtDelete->bind_param("i", $clubID);
            $stmtDelete->execute();

            // Insert new advisor
            $insertAdvisor = "INSERT INTO club_advisors (staffID, clubID) VALUES (?, ?)";
            $stmtInsert = $conn->prepare($insertAdvisor);
            $stmtInsert->bind_param("ii", $advisorID, $clubID);
            
            if (!$stmtInsert->execute()) {
                throw new Exception("Error assigning advisor");
            }

            // Commit transaction
            $conn->commit();
            
            $_SESSION['success_message'] = "Club successfully updated!";
            header("Location: ubakp_club_assoc.php");
            exit();

        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $errors[] = "Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kemaskini Kelab</title>
    <link rel="stylesheet" href="club_homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Base styles */
        *, *::before, *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            min-height: 100vh;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f0f2f5;
            color: #1a1a1a;
            line-height: 1.6;
        }

        /* Main content area */
        main {
            margin-left: 250px;
            padding: 2rem;
            min-height: 100vh;
            transition: margin-left 0.3s ease;
        }

        /* Header Section - Matching mpp_profile.php style */
        .header-section {
            margin-bottom: 2.5rem;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 2rem;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            font-size: 28px;
            font-weight: 600;
            text-align: center;
            margin: 0;
        }

        /* Form Container */
        .form-container {
            background-color: white;
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 0 auto;
            animation: fadeIn 0.5s ease-out;
        }

        /* Form Groups */
        .form-group {
            margin-bottom: 1.8rem;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            color: #1a365d;
            margin-bottom: 0.8rem;
            font-size: 0.95rem;
        }

        /* Form Inputs */
        input, select, textarea {
            width: 100%;
            padding: 0.875rem 1rem;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.2s ease;
            background-color: #f8fafc;
        }

        input:hover, select:hover, textarea:hover {
            border-color: #90cdf4;
            background-color: #fff;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #0061f2;
            box-shadow: 0 0 0 3px rgba(0, 97, 242, 0.15);
            background-color: #fff;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        /* Advisor Search */
        .advisor-search-container {
            position: relative;
        }

        #advisorResults {
            position: absolute;
            width: 100%;
            max-height: 200px;
            overflow-y: auto;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .advisor-option {
            padding: 0.75rem 1rem;
            cursor: pointer;
            transition: background-color 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .advisor-option:hover {
            background-color: #f0f9ff;
        }

        /* Selected Advisor */
        .selected-advisor {
            margin-top: 0.75rem;
            padding: 0.75rem;
            background-color: #f0f9ff;
            border: 2px solid #bae6fd;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        /* Form Actions */
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 2.5rem;
        }

        .btn {
            padding: 0.875rem 1.5rem;
            border-radius: 8px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            border: none;
        }

        .btn-primary {
            background-color: #0061f2;
            color: white;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(0, 97, 242, 0.2);
        }

        .btn-cancel {
            background-color: #ef4444;
            color: white;
        }

        .btn-cancel:hover {
            background-color: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 6px rgba(239, 68, 68, 0.2);
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            main {
                margin-left: 0;
                padding: 1rem;
            }

            .form-container {
                padding: 1.5rem;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <?php include('ubakp_sidebar.php'); ?>
    <main>
        <header class="header">
            <div class="header-section">
                <div class="welcome-card">
                    <div class="welcome-text">
                        <h1><strong>Update Club Details</strong></h1>
                    </div>
                </div>
            </div>
        </header>

        <div class="form-container">
            <form action="ubakp_edit_club.php?id=<?php echo htmlspecialchars($clubID); ?>" method="POST">
                <div class="form-group">
                    <label for="clubName">Club Name:</label>
                    <input type="text" id="clubName" name="clubName" value="<?php echo htmlspecialchars($club['clubName']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="clubDescription">Club Description:</label>
                    <textarea id="clubDescription" name="clubDescription" required><?php echo htmlspecialchars($club['clubDescription']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="clubDimension">Club Dimension:</label>
                    <select id="clubDimension" name="clubDimension" required>
                        <option value="Pengurusan dan Kepimpinan" <?php echo ($club['clubDimension'] == 'Pengurusan dan Kepimpinan') ? 'selected' : ''; ?>>Pengurusan dan Kepimpinan</option>
                        <option value="Akademik dan Kerjaya" <?php echo ($club['clubDimension'] == 'Akademik dan Kerjaya') ? 'selected' : ''; ?>>Akademik dan Kerjaya</option>
                        <option value="Etika dan Rohani" <?php echo ($club['clubDimension'] == 'Etika dan Rohani') ? 'selected' : ''; ?>>Etika dan Rohani</option>
                        <option value="Keusahawanan" <?php echo ($club['clubDimension'] == 'Keusahawanan') ? 'selected' : ''; ?>>Keusahawanan</option>
                        <option value="Teknikal dan Inovasi" <?php echo ($club['clubDimension'] == 'Teknikal dan Inovasi') ? 'selected' : ''; ?>>Teknikal dan Inovasi</option>
                        <option value="Sukarelawan" <?php echo ($club['clubDimension'] == 'Sukarelawan') ? 'selected' : ''; ?>>Sukarelawan</option>
                        <option value="Budaya dan Entiti Nasional" <?php echo ($club['clubDimension'] == 'Budaya dan Entiti Nasional') ? 'selected' : ''; ?>>Budaya dan Entiti Nasional</option>
                        <option value="Sukan dan Rekreasi" <?php echo ($club['clubDimension'] == 'Sukan dan Rekreasi') ? 'selected' : ''; ?>>Sukan dan Rekreasi</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="advisorSearch">Advisor:</label>
                    <div class="advisor-search-container">
                        <input type="text" 
                               id="advisorSearch" 
                               name="advisorSearch" 
                               class="advisor-search-input"
                               placeholder="Cari nama penasihat..." 
                               autocomplete="off"
                               value="<?php echo htmlspecialchars($current_advisor['staffFName'] ?? ''); ?>"
                               required>
                        <div id="advisorResults"></div>
                        <input type="hidden" 
                               id="advisorID" 
                               name="advisorID" 
                               value="<?php echo htmlspecialchars($current_advisor['staffID'] ?? ''); ?>" 
                               required>
                        <div id="selectedAdvisor" class="selected-advisor" style="display: <?php echo $current_advisor ? 'flex' : 'none'; ?>">
                            <i class="fas fa-user-check"></i>
                            <span id="selectedAdvisorName"><?php echo htmlspecialchars($current_advisor['staffFName'] ?? ''); ?></span>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="clubUsername">Club Username:</label>
                    <input type="text" id="clubUsername" name="clubUsername" value="<?php echo htmlspecialchars($club['clubUsername']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="clubPassword">Club Password:</label>
                    <input type="text" id="clubPassword" name="clubPassword" value="<?php echo htmlspecialchars($club['clubPassword']); ?>" required>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Club
                    </button>
                    <a href="club_assoc.php" class="btn btn-cancel">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </main>

    <script>
        const advisors = <?php echo json_encode($advisors); ?>;
        const advisorSearch = document.getElementById('advisorSearch');
        const advisorResults = document.getElementById('advisorResults');
        const advisorID = document.getElementById('advisorID');
        const selectedAdvisor = document.getElementById('selectedAdvisor');
        const selectedAdvisorName = document.getElementById('selectedAdvisorName');

        function showResults() {
            advisorResults.style.display = 'block';
        }

        function hideResults() {
            setTimeout(() => {
                advisorResults.style.display = 'none';
            }, 200);
        }

        function updateSelectedAdvisor(name) {
            selectedAdvisorName.textContent = name;
            selectedAdvisor.style.display = 'flex';
        }

        advisorSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            advisorResults.innerHTML = '';

            if (searchTerm.length > 0) {
                const filteredAdvisors = advisors.filter(advisor => 
                    advisor.staffFName.toLowerCase().includes(searchTerm)
                );

                if (filteredAdvisors.length > 0) {
                    filteredAdvisors.forEach(advisor => {
                        const div = document.createElement('div');
                        div.className = 'advisor-option';
                        div.innerHTML = `<i class="fas fa-user"></i>${advisor.staffFName}`;
                        div.addEventListener('click', function() {
                            advisorSearch.value = advisor.staffFName;
                            advisorID.value = advisor.staffID;
                            updateSelectedAdvisor(advisor.staffFName);
                            hideResults();
                        });
                        advisorResults.appendChild(div);
                    });
                    showResults();
                } else {
                    const div = document.createElement('div');
                    div.className = 'advisor-option';
                    div.innerHTML = '<i class="fas fa-info-circle"></i>Tiada penasihat dijumpai';
                    advisorResults.appendChild(div);
                    showResults();
                }
            } else {
                hideResults();
            }
        });

        advisorSearch.addEventListener('focus', showResults);
        advisorSearch.addEventListener('blur', hideResults);
    </script>
</body>
</html>