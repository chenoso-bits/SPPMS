<?php
    // Start session
    session_start();

    if (!isset($_SESSION['staffID']) || !isset($_SESSION['staffRole'])) {
        echo "Session for staffID or staffRole is not set!";
        exit();
    }
    
    // Database connection
    include('../../connection.php');

    // Check if the connection is successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Initialize filter values
    $searchTitle = $_GET['searchTitle'] ?? '';
    $searchDate = $_GET['searchDate'] ?? '';
    $searchStatus = $_GET['searchStatus'] ?? '';
    $searchCategory = $_GET['searchCategory'] ?? '';
    $searchClub = $_GET['searchClub'] ?? '';

    // Query to fetch paperwork and club details with filters
    $sql = "SELECT p.program_name, p.created_at, p.status, p.id, p.category, c.clubName
        FROM paperwork p
        JOIN club c ON c.clubID = p.clubID
        WHERE p.program_name LIKE ? AND p.created_at LIKE ? AND p.status LIKE ? AND c.clubName LIKE ? AND p.category LIKE ?";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $likeTitle = "%$searchTitle%";
    $likeDate = "%$searchDate%";
    $likeStatus = "%$searchStatus%";
    $likeClub = "%$searchClub%";
    $likeCategory = "%$searchCategory%"; // Add this line
    $stmt->bind_param("sssss", $likeTitle, $likeDate, $likeStatus, $likeClub, $likeCategory); // Update to include category

    // Execute the query
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the results
    $paperwork = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $paperwork[] = [
                'programName' => $row['program_name'],
                'category' => $row['category'],
                'submissionDate' => $row['created_at'],
                'status' => $row['status'],
                'id' => $row['id'],
                'clubName' => $row['clubName']
            ];
        }
    } else {
        echo "No paperwork found.";
    }
    
    // Close the statement and connection
    $stmt->close();
    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
</head>
<body>
    <?php include('ubakp_sidebar.php'); ?>
    
    <div class="content-wrapper">
        <!-- Welcome Section -->
        <div class="header-section">
            <div class="welcome-card">
                <div class="welcome-text">
                    <h1>Welcome, <strong><?php echo htmlspecialchars($_SESSION['staffFName']); ?>!</strong></h1>
                    <p class="role-text">Staff role: <strong><?php echo htmlspecialchars($_SESSION['staffRole']); ?></strong></p>
                </div>
            </div>
        </div>

        <div class="main-content">
            <!-- Filter Section -->
            <div class="filter-container">
                <div class="section-header">
                    <h2><i class="fas fa-filter"></i> Filter Options</h2>
                </div>
                <form method="GET" action="" class="filter-form">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="searchTitle">
                                <i class="fas fa-heading"></i> Paperwork Title
                            </label>
                            <input type="text" id="searchTitle" name="searchTitle" 
                                   value="<?php echo htmlspecialchars($searchTitle); ?>">
                        </div>
                        <div class="filter-group">
                            <label for="searchDate">
                                <i class="fas fa-calendar-alt"></i> Submission Time
                            </label>
                            <input type="date" id="searchDate" name="searchDate" 
                                   value="<?php echo htmlspecialchars($searchDate); ?>">
                        </div>
                        <div class="filter-group">
                            <label for="searchStatus">
                                <i class="fas fa-tasks"></i> Status
                            </label>
                            <select id="searchStatus" name="searchStatus">
                                <option value="" <?php echo $searchStatus == '' ? 'selected' : ''; ?>>All</option>
                                <option value="Dihantar" <?php echo $searchStatus == 'Dihantar' ? 'selected' : ''; ?>>Dihantar</option>
                                <option value="Disemak" <?php echo $searchStatus == 'Disemak' ? 'selected' : ''; ?>>Disemak</option>
                                <option value="Diluluskan" <?php echo $searchStatus == 'Diluluskan' ? 'selected' : ''; ?>>Diluluskan</option>
                            </select>
                        </div>
                    </div>
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="searchCategory">
                                <i class="fas fa-tag"></i> Category
                            </label>
                            <select id="searchCategory" name="searchCategory">
                                <option value="" <?php echo $searchCategory == '' ? 'selected' : ''; ?>>All</option>
                                <option value="JHEPA" <?php echo $searchCategory == 'JHEPA' ? 'selected' : ''; ?>>JHEPA</option>
                                <option value="JPM" <?php echo $searchCategory == 'JPM' ? 'selected' : ''; ?>>JPM</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label for="searchClub">
                                <i class="fas fa-users"></i> Club
                            </label>
                            <input type="text" id="searchClub" name="searchClub" 
                                   value="<?php echo htmlspecialchars($searchClub); ?>">
                        </div>
                        <div class="filter-buttons">
                            <button type="submit" class="apply-filter-btn">
                                <i class="fas fa-search"></i> Apply Filter
                            </button>
                            <button type="button" onclick="window.location.href='ubakp_homepage.php'" class="clear-filter-btn">
                                <i class="fas fa-undo"></i> Clear Filter
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Paperwork List Section -->
            <div class="paperwork-section">
                <div class="section-header">
                    <h2><i class="fas fa-clipboard-list"></i> Senarai Kertas Kerja</h2>
                </div>
                <div class="table-container">
                    <table id="paperworkTable" class="display responsive nowrap">
                        <thead>
                            <tr>
                                <th>Paperwork Title</th>
                                <th>Category</th>
                                <th>Submission</th>
                                <th>Status</th>
                                <th>Club</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($paperwork)): ?>
                                <?php foreach ($paperwork as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['programName']); ?></td>
                                        <td><?php echo htmlspecialchars($item['category']); ?></td>
                                        <td><?php echo htmlspecialchars($item['submissionDate']); ?></td>
                                        <td>
                                            <span class="status-badge <?php echo strtolower(htmlspecialchars($item['status'])); ?>">
                                                <?php echo htmlspecialchars($item['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($item['clubName']); ?></td>
                                        <td>
                                            <a href="ubakp_view_paperwork.php?id=<?php echo htmlspecialchars($item['id']); ?>" 
                                               class="action-btn" data-page="viewppw">
                                                <i class="fas fa-eye"></i> View
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Base Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
        }

        .content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s ease;
        }

        /* Header Section */
        .header-section {
            margin-bottom: 30px;
        }

        .welcome-card {
            background: linear-gradient(135deg, #0061f2 0%, #00a6f9 100%);
            border-radius: 15px;
            padding: 30px;
            color: white;
            box-shadow: 0 4px 15px rgba(0, 97, 242, 0.1);
        }

        .welcome-text h1 {
            margin: -10px 0 0 20px;
            font-size: 2.5em;
            font-weight: 600;
        }

        .role-text {
            margin: 10px 0 0 20px;
            font-size: 1.2em;
            opacity: 0.9;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-bottom: 30px;
            padding-left: 50px;
        }

        /* Filter Section */
        .filter-container {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
        }

        .section-header {
            margin-bottom: 20px;
        }

        .section-header h2 {
            color: #0061f2;
            font-size: 1.25em;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .filter-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .filter-row {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
            margin: 0 30px 0 0;
        }

        .filter-group label {
            display: block;
            margin-bottom: 8px;
            color: #495057;
            font-weight: 500;
        }

        .filter-group input,
        .filter-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 8px;
            font-size: 0.9em;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .apply-filter-btn,
        .clear-filter-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .apply-filter-btn {
            background: #0061f2;
            color: white;
        }

        .clear-filter-btn {
            background: #6c757d;
            color: white;
        }

        .apply-filter-btn:hover,
        .clear-filter-btn:hover {
            transform: translateY(-2px);
        }

        /* Table Styles */
        .table-container {
            margin-top: 20px;
        }

        #paperworkTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        #paperworkTable th {
            background: #0061f2;
            color: white;
            padding: 15px;
            font-weight: 500;
        }

        #paperworkTable td {
            padding: 15px;
            border-bottom: 1px solid #e9ecef;
            vertical-align: middle;
        }

        /* Status Badges */
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .status-badge.dihantar {
            background-color: #fff8f1;
            color: #fd7e14;
        }

        .status-badge.disemak {
            background-color: #e8f4fd;
            color: #0d6efd;
        }

        .status-badge.diluluskan {
            background-color: #e8f8f5;
            color: #20c997;
        }

        /* Action Button */
        .action-btn {
            background: #e8f4fd;
            color: #0d6efd;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9em;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s ease;
        }

        .action-btn:hover {
            background: #0d6efd;
            color: white;
        }

        /* DataTables Styling */
        .dataTables_wrapper .dataTables_length select,
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #ced4da;
            border-radius: 6px;
            padding: 6px 12px;
            margin-bottom: 10px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 6px 12px;
            margin: 0 4px;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #0061f2;
            border-color: #0061f2;
            color: white !important;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .content-wrapper {
                margin-left: 0;
            }
            
            .filter-row {
                flex-direction: column;
            }

            .filter-group {
                width: 100%;
            }
        }
    </style>

    <script>
        $(document).ready(function() {
            $('#paperworkTable').DataTable({
                responsive: true,
                pageLength: 10,
                language: {
                    search: "🔍 Search:",
                    lengthMenu: "Show _MENU_ entries",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "«",
                        last: "»",
                        next: "→",
                        previous: "←"
                    }
                },
                columnDefs: [{
                    targets: -1,
                    orderable: false
                }],
                order: [[2, 'desc']]
            });
        });
    </script>
</body>
</html>
