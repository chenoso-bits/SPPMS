<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MPP Sidebar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Import Font Awesome for icons */
        @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');

        /* Sidebar styles with new gradient */
        .sidebar {
            font-family: 'Segoe UI', Arial, sans-serif;
            display: flex;
            flex-direction: column;
            width: 250px;
            position: fixed;
            height: 100vh;
            background: linear-gradient(to bottom, 
                #ffffff 0%,
                #ffffff 50%,
                #007bff 100%);
            padding: 20px;
            left: 0;
            z-index: 100;
            box-shadow: 5px 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 0 15px 15px 0;
        }

        /* Rest of the styles remain the same */
        .sidebar img {
            width: 60%;
            height: auto;
            display: block;
            margin: 0 auto 30px;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }

        .sidebar img:hover {
            transform: scale(1.05);
        }

        .sidebar-buttons {
            display: flex;
            flex-direction: column;
            gap: 15px;
            flex: 1;
        }

        .sidebar-btn {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            background-color: transparent;
            color: #495057;
            text-decoration: none;
            border-radius: 8px;
            border: 1px solid transparent;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(5px);
            background-color: rgba(255, 255, 255, 0.9);
        }

        .sidebar-btn i {
            margin-right: 12px;
            font-size: 1.1em;
            transition: transform 0.3s ease;
        }

        .sidebar-btn.active {
            background-color: #007bff;
            color: white;
            box-shadow: 0 8px 25px rgba(0, 123, 255, 0.4);
            transform: translateY(-3px) scale(1.02);
        }

        .sidebar-btn:not(.active):hover {
            background-color: white;
            border: 1px solid #007bff;
            color: #007bff;
            box-shadow: 0 6px 20px rgba(0, 123, 255, 0.2);
            transform: translateY(-2px) scale(1.01);
        }

        .sidebar-btn:active {
            transform: translateY(1px) scale(0.98);
            box-shadow: 0 2px 10px rgba(0, 123, 255, 0.2);
        }

        .sidebar-btn:hover i,
        .sidebar-btn.active i {
            transform: scale(1.1);
        }

        .logout-container {
            margin-top: auto;
            padding-top: 20px;
            padding-bottom: 20px;
            position: relative;
            z-index: 1;
        }

        .logout-btn {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            background-color: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-bottom: 20px;
            position: relative;
            overflow: hidden;
        }

        .logout-btn i {
            margin-right: 12px;
            font-size: 1.1em;
            transition: transform 0.3s ease;
        }

        .logout-btn:hover {
            background-color: #c82333;
            box-shadow: 0 8px 25px rgba(220, 53, 69, 0.3);
            transform: translateY(-3px) scale(1.02);
        }

        .logout-btn:active {
            transform: translateY(1px) scale(0.98);
            box-shadow: 0 2px 10px rgba(220, 53, 69, 0.2);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .sidebar-btn::after,
        .logout-btn::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: width 0.3s ease-out, height 0.3s ease-out;
        }

        .sidebar-btn:active::after,
        .logout-btn:active::after {
            width: 200px;
            height: 200px;
            opacity: 0;
        }
    </style>
</head>
<body>
    <!-- Sidebar Section -->
    <aside class="sidebar">
        <img src="../../image/UTeM.png" alt="PP Logo">
        <div class="sidebar-buttons">
            <a href="ubakp_homepage.php" class="sidebar-btn" data-page="home">
                <i class="fas fa-home"></i>
                Home
            </a>
            <a href="ubakp_club_assoc.php" class="sidebar-btn" data-page="club">
                <i class="fas fa-building"></i>
                Club/Association
            </a>
            <a href="ubakp_profile.php" class="sidebar-btn" data-page="profile">
                <i class="fas fa-user"></i>
                Profile
            </a>
        </div>
        <div class="logout-container">
            <a href="../../index.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </div>
    </aside>

    <script>
        // Function to set active button based on current page
        function setActiveButton() {
            // Get current page URL
            const currentPath = window.location.pathname;
            
            // Remove active class from all buttons
            document.querySelectorAll('.sidebar-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Add active class to the button that matches the current page
            if (currentPath.includes('ubakp_homepage.php')) {
                document.querySelector('[data-page="home"]').classList.add('active');
            } else if (currentPath.includes('club_assoc.php')) {
                document.querySelector('[data-page="club"]').classList.add('active');
            } else if (currentPath.includes('ubakp_profile.php')) {
                document.querySelector('[data-page="profile"]').classList.add('active');
            } else if (currentPath.includes('ubakp_view_paperwork.php')) {
                document.querySelector('[data-page="viewppw"]').classList.add('active');
            }
        }

        // Run when the page loads
        document.addEventListener('DOMContentLoaded', setActiveButton);

        // Add click event listeners to all sidebar buttons
        document.querySelectorAll('.sidebar-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                document.querySelectorAll('.sidebar-btn').forEach(b => {
                    b.classList.remove('active');
                });
                // Add active class to clicked button
                this.classList.add('active');
            });
        });
    </script>
</body>
</html>